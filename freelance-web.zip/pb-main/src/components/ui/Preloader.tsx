import { useEffect, useRef, useState } from 'react';
import { gsap } from '@/lib/gsap';

interface PreloaderProps {
  onComplete: () => void;
}

// Total duration the preloader is visible before exit begins (ms)
const HOLD_MS = 1000;

export default function Preloader({ onComplete }: PreloaderProps) {
  const rootRef      = useRef<HTMLDivElement>(null);
  const barRef       = useRef<HTMLDivElement>(null);
  const dotRef       = useRef<HTMLDivElement>(null);
  const logoRef      = useRef<HTMLImageElement>(null);
  const countRef     = useRef<HTMLSpanElement>(null);
  const contentRef   = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);

  // Mount flag — lets CSS transitions start after first paint
  useEffect(() => {
    // Defer one frame so the browser has painted the initial state
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, []);

  useEffect(() => {
    if (!mounted) return;

    const root    = rootRef.current;
    const bar     = barRef.current;
    const dot     = dotRef.current;
    const logo    = logoRef.current;
    const count   = countRef.current;
    const content = contentRef.current;
    if (!root || !bar || !dot || !logo || !count || !content) return;

    // ── 1. Animate progress bar + counter via GSAP (GPU transform on bar) ──
    const proxy = { value: 0 };
    const barTween = gsap.to(proxy, {
      value: 100,
      duration: HOLD_MS / 1000,
      ease: 'none',
      onUpdate() {
        const v = Math.round(proxy.value);
        const pct = `${proxy.value.toFixed(2)}%`;
        bar.style.width = pct;
        dot.style.left  = pct;
        if (count) count.textContent = `${v}%`;
      },
    });

    // ── 2. Logo subtle breathe (runs only during hold phase) ──
    const logoPulse = gsap.to(logo, {
      scale: 1.04,
      opacity: 0.85,
      duration: 1.1,
      ease: 'sine.inOut',
      yoyo: true,
      repeat: -1,
    });

    // ── 3. Exit sequence after hold ──
    const exitTimer = setTimeout(() => {
      // Kill the pulse so it doesn't fight the exit
      logoPulse.kill();
      barTween.kill();

      const tl = gsap.timeline({
        onComplete: () => {
          // Signal App that preloader is done — App will reveal the shell
          onComplete();
        },
      });

      // a. Content fades + scales out first
      tl.to(content, {
        opacity: 0,
        scale: 0.96,
        y: -12,
        duration: 0.4,
        ease: 'power3.in',
      });

      // b. Whole panel slides up off screen (GPU transform, no layout)
      tl.to(root, {
        yPercent: -100,
        duration: 0.65,
        ease: 'expo.inOut',
      }, '-=0.1');

    }, HOLD_MS);

    return () => {
      clearTimeout(exitTimer);
      barTween.kill();
      logoPulse.kill();
      gsap.killTweensOf([root, content, logo, proxy]);
    };
  }, [mounted, onComplete]);

  return (
    <div
      ref={rootRef}
      aria-hidden="true"
      className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-brand-primary overflow-hidden select-none will-change-transform"
    >
      {/* Content wrapper — fades out independently before panel slides */}
      <div
        ref={contentRef}
        className="flex flex-col items-center gap-10 will-change-transform"
      >
        {/* Logo */}
        <div className="relative w-28 h-28 flex items-center justify-center">
          {/* Soft glow ring */}
          <div className="absolute inset-0 rounded-full bg-black/10 blur-2xl scale-110" />
          <img
            ref={logoRef}
            src="/logo.png"
            alt="Phoenix Brothers"
            className="relative w-full h-full object-contain brightness-0 will-change-transform"
            style={{
              // Start invisible — GSAP will drive opacity via the pulse tween
              opacity: mounted ? 1 : 0,
              transition: mounted ? 'none' : 'opacity 0.4s ease',
            }}
          />
        </div>

        {/* Progress track */}
        <div className="flex flex-col items-center gap-3 w-56">
          {/* Bar */}
          <div className="relative w-full h-[1.5px] bg-black/15 rounded-full overflow-visible">
            <div
              ref={barRef}
              className="absolute left-0 top-0 h-full bg-black rounded-full will-change-[width]"
              style={{ width: '0%' }}
            />
            {/* Leading dot */}
            <div
              ref={dotRef}
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-[5px] h-[5px] rounded-full bg-black will-change-[left]"
              style={{ left: '0%' }}
            />
          </div>

          {/* Counter */}
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-black tracking-[0.35em] text-black/50 uppercase">
              Loading
            </span>
            <span
              ref={countRef}
              className="text-[9px] font-black tracking-[0.2em] text-black tabular-nums"
            >
              0%
            </span>
          </div>
        </div>

        {/* Brand name — fades in with a slight delay */}
        <div
          className="flex flex-col items-center gap-0.5"
          style={{
            opacity: mounted ? 1 : 0,
            transform: mounted ? 'translateY(0)' : 'translateY(8px)',
            transition: 'opacity 0.6s ease 0.2s, transform 0.6s ease 0.2s',
          }}
        >
          <span className="text-[11px] font-black tracking-[0.5em] text-black/70 uppercase">
            Phoenix Brothers
          </span>
        </div>
      </div>
    </div>
  );
}
