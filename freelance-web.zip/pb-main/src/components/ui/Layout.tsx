import { ReactNode, memo } from 'react';

interface SectionProps {
  children: ReactNode;
  className?: string;
  id?: string;
  container?: boolean;
}

export function Section({ children, className, id, container = true }: SectionProps) {
  return (
    <section
      id={id}
      className={`py-12 md:py-24 lg:py-32 ${className || ''}`}
    >
      {container ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          {children}
        </div>
      ) : (
        children
      )}
    </section>
  );
}

interface PageLayoutProps {
  children: ReactNode;
}

export function PageLayout({ children }: PageLayoutProps) {
  return (
    <div className="min-h-screen w-full overflow-x-hidden">
      {children}
    </div>
  );
}

/**
 * PageBackground — memoized so it never re-renders.
 * will-change: transform promotes blur divs to their own compositor layers,
 * preventing repaint on scroll.
 */
export const PageBackground = memo(() => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
    {/* 64px line grid */}
    <div
      className="absolute inset-0 opacity-[0.02]"
      style={{
        backgroundImage: `linear-gradient(#F9F7F2 1px, transparent 1px), linear-gradient(90deg, #F9F7F2 1px, transparent 1px)`,
        backgroundSize: '64px 64px',
      }}
    />
    {/* Ambient glows — promoted to compositor layer to avoid repaint */}
    <div
      className="absolute top-[20%] left-[-10%] w-[min(600px,80vw)] h-[min(600px,80vw)] bg-brand-primary/5 blur-[120px] rounded-full"
      style={{ willChange: 'transform' }}
    />
    <div
      className="absolute bottom-[10%] right-[-5%] w-[min(400px,60vw)] h-[min(400px,60vw)] bg-brand-primary/5 blur-[100px] rounded-full"
      style={{ willChange: 'transform' }}
    />
  </div>
));

PageBackground.displayName = 'PageBackground';
