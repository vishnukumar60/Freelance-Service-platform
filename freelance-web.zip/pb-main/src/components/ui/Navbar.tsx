import { useState, useEffect, useRef, useCallback, memo } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import ThemeToggle from '@/components/ThemeToggle';
import { Menu, X } from 'lucide-react';

// ─── Static data — defined outside to never cause re-renders ─────────────────

const navLinks = [
  { name: 'Home',     path: '/' },
  { name: 'About',    path: '/about' },
  { name: 'Services', path: '/services' },
  { name: 'Team',     path: '/team' },
  { name: 'Contact',  path: '/contact' },
];

// ─── NavLink — isolated so only the active one re-renders on route change ────

const NavLink = memo(({ link, isActive }: { link: typeof navLinks[0]; isActive: boolean }) => (
  <Link
    to={link.path}
    className={cn(
      'relative px-4 py-2 text-[0.8rem] font-black tracking-[0.08em] uppercase',
      'whitespace-nowrap rounded-full transition-colors duration-200',
      isActive
        ? 'text-brand-primary'
        : 'text-brand-text/80 hover:text-brand-primary hover:bg-brand-text/5',
    )}
  >
    <span className="relative z-10">{link.name}</span>
    {isActive && (
      <motion.div
        layoutId="navActive"
        className="absolute inset-0 bg-brand-primary/10 rounded-full border border-brand-primary/20"
        // Use tween instead of spring — spring fights the page transition sweep
        transition={{ type: 'tween', duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
      />
    )}
  </Link>
));
NavLink.displayName = 'NavLink';

// ─── MobileNavLink — isolated for the same reason ────────────────────────────

const MobileNavLink = memo(({ link, index, isActive }: {
  link: typeof navLinks[0]; index: number; isActive: boolean;
}) => (
  <motion.div
    initial={{ opacity: 0, x: -24 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -16 }}
    transition={{ delay: index * 0.06, duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
  >
    <Link
      to={link.path}
      className="group flex items-center gap-4 py-4 border-b border-brand-text/8 last:border-0"
    >
      <span className={cn(
        'font-mono text-[0.6rem] tracking-[0.3em] font-bold w-6 shrink-0 transition-colors duration-200',
        isActive ? 'text-brand-primary' : 'text-brand-text/20 group-hover:text-brand-primary/60',
      )}>
        {String(index + 1).padStart(2, '0')}
      </span>
      <span className={cn(
        'text-[clamp(1.75rem,7vw,2.5rem)] font-black tracking-tight uppercase leading-none transition-colors duration-200 flex-1',
        isActive ? 'text-brand-primary' : 'text-brand-text/80 group-hover:text-brand-text',
      )}>
        {link.name}
      </span>
      <div className={cn(
        'w-2 h-2 rounded-full shrink-0 transition-all duration-200',
        isActive
          ? 'bg-brand-primary scale-100'
          : 'bg-brand-text/10 scale-75 group-hover:bg-brand-primary/50 group-hover:scale-100',
      )} />
    </Link>
  </motion.div>
));
MobileNavLink.displayName = 'MobileNavLink';

// ─── Navbar ───────────────────────────────────────────────────────────────────

export default function Navbar() {
  const [scrolled, setScrolled]     = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const pathname = location.pathname;

  // Close mobile menu on route change
  useEffect(() => { setMobileOpen(false); }, [pathname]);

  // Passive, rAF-throttled scroll handler
  useEffect(() => {
    let rafId = 0;
    const onScroll = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => setScrolled(window.scrollY > 20));
    };
    // Set initial state without waiting for first scroll
    setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => { window.removeEventListener('scroll', onScroll); cancelAnimationFrame(rafId); };
  }, []);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const toggleMobile = useCallback(() => setMobileOpen(v => !v), []);

  return (
    <>
      {/*
        Header wrapper:
        - Fixed height via min-h so it never shifts regardless of inner content
        - Consistent padding — no breakpoint-dependent py changes that cause height jumps
        - pointer-events-none on wrapper, restored on nav pill
      */}
      <header className="fixed top-0 left-0 right-0 z-[100] flex justify-center pointer-events-none px-3 sm:px-4 pt-3 md:pt-4">
        <nav
          className={cn(
            // Fixed structural classes — never change, so no layout shift
            'w-full max-w-[1100px] flex items-center justify-between pointer-events-auto',
            // Consistent padding — same on all breakpoints, no height jump
            'px-3 md:px-5 py-2.5',
            // Rounded pill always present — no shape change on scroll
            'rounded-full',
            // Only visual properties transition (bg, border, shadow) — not size/position
            'transition-[background-color,border-color,box-shadow,backdrop-filter] duration-400 ease-out',
            scrolled
              ? 'bg-brand-surface/92 backdrop-blur-lg border border-brand-text/10 shadow-lg shadow-black/8'
              : 'bg-brand-surface/75 backdrop-blur-md border border-brand-text/6 shadow-md shadow-black/4',
          )}
        >
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 md:gap-2.5 shrink-0">
            {/*
              Fixed-size container — no w-9/w-11 responsive change that shifts layout.
              Logo box is always the same size; only the inner ring animates (opacity only,
              not transform) to avoid triggering layout recalculation.
            */}
            <div className="relative w-9 h-9 flex items-center justify-center shrink-0">
              <div
                className={cn(
                  'absolute inset-0 border rounded-xl transition-[opacity,border-color,background-color] duration-400',
                  scrolled
                    ? 'border-brand-primary/30 bg-brand-primary/8 opacity-100'
                    : 'border-brand-primary/15 bg-brand-primary/4 opacity-80',
                )}
              />
              <img
                src="/logo.png"
                alt="Phoenix Brothers"
                className="w-5 h-5 object-contain relative z-10"
                // Explicit dimensions prevent layout shift while image loads
                width={20}
                height={20}
              />
            </div>
            <div className="flex flex-col leading-none">
              <span className="text-brand-text font-black text-[13px] tracking-[0.15em] uppercase">Phoenix</span>
              <span className="text-brand-text/60 font-bold text-[10px] tracking-[0.2em] uppercase">Brothers</span>
            </div>
          </Link>

          {/* Desktop nav links */}
          <div className="hidden md:flex flex-1 items-center justify-center gap-0.5 lg:gap-1">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                link={link}
                isActive={pathname === link.path}
              />
            ))}
          </div>

          {/* Right side: theme toggle + hamburger */}
          <div className="flex items-center gap-1.5 shrink-0">
            <div className="border-l border-brand-text/10 pl-2 md:pl-2.5">
              <ThemeToggle />
            </div>
            {/* Hamburger — mobile only, fixed size so it never shifts */}
            <button
              onClick={toggleMobile}
              aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={mobileOpen}
              className="md:hidden w-9 h-9 rounded-full flex items-center justify-center text-brand-text/70 hover:text-brand-primary hover:bg-brand-text/5 transition-colors duration-200 ml-0.5"
            >
              {/* AnimatePresence so icon swap doesn't cause size flash */}
              <AnimatePresence mode="wait" initial={false}>
                {mobileOpen ? (
                  <motion.span
                    key="close"
                    initial={{ opacity: 0, rotate: -45 }}
                    animate={{ opacity: 1, rotate: 0 }}
                    exit={{ opacity: 0, rotate: 45 }}
                    transition={{ duration: 0.15 }}
                  >
                    <X size={18} />
                  </motion.span>
                ) : (
                  <motion.span
                    key="menu"
                    initial={{ opacity: 0, rotate: 45 }}
                    animate={{ opacity: 1, rotate: 0 }}
                    exit={{ opacity: 0, rotate: -45 }}
                    transition={{ duration: 0.15 }}
                  >
                    <Menu size={18} />
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile full-screen menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            key="mobile-menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="fixed inset-0 z-[90] md:hidden"
          >
            <div className="absolute inset-0 bg-brand-dark/98 backdrop-blur-2xl" />

            <div className="relative h-full flex flex-col px-8 pt-24 pb-10">
              <nav className="flex flex-col flex-1 justify-center gap-1">
                {navLinks.map((link, i) => (
                  <MobileNavLink
                    key={link.path}
                    link={link}
                    index={i}
                    isActive={pathname === link.path}
                  />
                ))}
              </nav>

              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35, duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
                className="flex items-center justify-between pt-6 border-t border-brand-text/8"
              >
                <span className="text-brand-text/30 text-[0.65rem] font-black tracking-[0.3em] uppercase">
                  Phoenix Brothers
                </span>
                <Link
                  to="/contact"
                  className="flex items-center gap-2 px-5 py-2.5 bg-brand-primary text-white font-black rounded-full text-[0.65rem] tracking-[0.2em] uppercase active:scale-95 transition-transform duration-200 touch-manipulation"
                >
                  Let's Talk
                </Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
