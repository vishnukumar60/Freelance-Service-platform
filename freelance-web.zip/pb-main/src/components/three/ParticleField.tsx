﻿import { useRef, useMemo, memo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useTheme } from '@/components/ThemeProvider';

const [C_MOB, C_DSK, R, SPEED, AMP] = [8000, 24000, 2.6, 0.1, 2];

const ParticleField = memo(() => {
  const pointsRef = useRef<THREE.Points>(null!);
  const matRef = useRef<THREE.PointsMaterial>(null!);
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';

  const count = useMemo(() => (typeof window !== 'undefined' && window.innerWidth < 768 ? C_MOB : C_DSK), []);
  const targetColor = useMemo(() => new THREE.Color(isDark ? '#191222' : '#D8C3A5'), [isDark]);

  const pos = useMemo(() => {
    const p = new Float32Array(count * 3), inc = Math.PI * (3 - Math.sqrt(5)), off = 2 / count;
    for (let i = 0; i < count; i++) {
      const y = (i * off - 1) + off / 2, r = Math.sqrt(1 - y * y), phi = i * inc;
      p.set([Math.cos(phi) * r * R, y * R, Math.sin(phi) * r * R], i * 3);
    }
    return p;
  }, [count]);

  useFrame((state, delta) => {
    const { current: pts } = pointsRef, { current: mat } = matRef;
    const t = state.clock.elapsedTime, b = Math.sin(t * SPEED) * 0.5 + 0.5;

    pts.rotation.y += delta * 0.1;
    pts.rotation.z = Math.sin(t * 0.2) * 0.05;
    pts.scale.setScalar(1 + b * AMP);

    mat.size = THREE.MathUtils.lerp(mat.size, 0.05 + b * 0.02, 0.1);
    mat.opacity = THREE.MathUtils.lerp(mat.opacity, isDark ? 0.9 : 0.9, 0.05);
    mat.color.lerp(targetColor, 0.03);
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={pos} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial ref={matRef} size={0.06} transparent depthWrite={false} sizeAttenuation blending={THREE.AdditiveBlending} />
    </points>
  );
});

ParticleField.displayName = 'ParticleField';
export default ParticleField;