import { motion, HTMLMotionProps } from 'motion/react';
import { ReactNode, memo } from 'react';

type AnimationType = 'fadeUp' | 'slideLeft' | 'slideRight' | 'scaleUp';

interface AnimatedSectionProps extends HTMLMotionProps<'div'> {
  children: ReactNode;
  animation?: AnimationType;
  delay?: number;
  duration?: number;
  className?: string;
}

const animations = {
  fadeUp: {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
  },
  slideLeft: {
    initial: { opacity: 0, x: -50 },
    whileInView: { opacity: 1, x: 0 },
  },
  slideRight: {
    initial: { opacity: 0, x: 50 },
    whileInView: { opacity: 1, x: 0 },
  },
  scaleUp: {
    initial: { opacity: 0, scale: 0.9 },
    whileInView: { opacity: 1, scale: 1 },
  },
};

const AnimatedSection = memo(({
  children,
  animation = 'fadeUp',
  delay = 0,
  duration = 0.6,
  className = '',
  ...props
}: AnimatedSectionProps) => {
  return (
    <motion.div
      initial={animations[animation].initial}
      whileInView={animations[animation].whileInView}
      viewport={{ once: true, margin: '-100px' }}
      transition={{
        duration,
        delay,
        ease: [0.22, 1, 0.36, 1],
      }}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  );
});

AnimatedSection.displayName = 'AnimatedSection';

export default AnimatedSection;
