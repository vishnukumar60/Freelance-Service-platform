import { useEffect, useRef } from 'react';
import { gsap } from '@/lib/gsap';

export function useHoverTilt() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    if (isTouch) return;

    // Set perspective once — not on every mousemove
    gsap.set(el, { transformPerspective: 1000 });

    const xTo = gsap.quickTo(el, 'rotateY', { duration: 0.45, ease: 'power2.out' });
    const yTo = gsap.quickTo(el, 'rotateX', { duration: 0.45, ease: 'power2.out' });

    // Cache rect and only refresh on resize — avoids getBoundingClientRect every mousemove
    let rect = el.getBoundingClientRect();
    let rafId = 0;

    const refreshRect = () => { rect = el.getBoundingClientRect(); };
    window.addEventListener('resize', refreshRect, { passive: true });
    window.addEventListener('scroll', refreshRect, { passive: true });

    const onMouseMove = (e: MouseEvent) => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top)  / rect.height - 0.5;
        xTo(x * 18);
        yTo(-y * 18);
      });
    };

    const onMouseLeave = () => {
      cancelAnimationFrame(rafId);
      xTo(0);
      yTo(0);
    };

    el.addEventListener('mousemove', onMouseMove);
    el.addEventListener('mouseleave', onMouseLeave);

    return () => {
      cancelAnimationFrame(rafId);
      el.removeEventListener('mousemove', onMouseMove);
      el.removeEventListener('mouseleave', onMouseLeave);
      window.removeEventListener('resize', refreshRect);
      window.removeEventListener('scroll', refreshRect);
      gsap.set(el, { rotateX: 0, rotateY: 0 });
    };
  }, []);

  return ref;
}

export function useMagnetic() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    if (isTouch) return;

    const xTo = gsap.quickTo(el, 'x', { duration: 0.4, ease: 'power2.out' });
    const yTo = gsap.quickTo(el, 'y', { duration: 0.4, ease: 'power2.out' });

    let rect = el.getBoundingClientRect();
    let rafId = 0;

    const refreshRect = () => { rect = el.getBoundingClientRect(); };
    window.addEventListener('resize', refreshRect, { passive: true });

    const onMouseMove = (e: MouseEvent) => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        const x = e.clientX - (rect.left + rect.width  / 2);
        const y = e.clientY - (rect.top  + rect.height / 2);
        xTo(x * 0.3);
        yTo(y * 0.3);
      });
    };

    const onMouseLeave = () => {
      cancelAnimationFrame(rafId);
      gsap.to(el, { x: 0, y: 0, duration: 0.4, ease: 'elastic.out(1, 0.3)' });
    };

    el.addEventListener('mousemove', onMouseMove);
    el.addEventListener('mouseleave', onMouseLeave);

    return () => {
      cancelAnimationFrame(rafId);
      el.removeEventListener('mousemove', onMouseMove);
      el.removeEventListener('mouseleave', onMouseLeave);
      window.removeEventListener('resize', refreshRect);
    };
  }, []);

  return ref;
}
