import * as THREE from 'three';

export const sharedMaterials = {
  phoenixBody: new THREE.MeshStandardMaterial({
    color: 0xff4d00,
    metalness: 0.9,
    roughness: 0.1,
    emissive: 0xff2200,
    emissiveIntensity: 0.5,
  }),
  glass: new THREE.MeshPhysicalMaterial({
    transparent: true,
    opacity: 0.2,
    roughness: 0,
    metalness: 1,
    transmission: 1,
    thickness: 0.5,
  }),
};

export function disposeScene(scene: THREE.Scene) {
  scene.traverse((object) => {
    if (!(object instanceof THREE.Mesh)) return;
    object.geometry.dispose();
    if (object.material instanceof Array) {
      object.material.forEach((material) => material.dispose());
    } else {
      object.material.dispose();
    }
  });
}
