import { useEffect, useState, useRef, useLayoutEffect, type ReactNode, lazy, Suspense, memo, useCallback } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, Link } from 'react-router-dom';
import Lenis from 'lenis';
import { gsap } from '@/lib/gsap';
import { ThemeProvider } from '@/components/ThemeProvider';
import { ArrowUp, Linkedin as LinkedinIcon, Instagram as InstagramIcon } from 'lucide-react';

import Navbar from '@/components/ui/Navbar';
import Preloader from '@/components/ui/Preloader';

// Lazy load pages
const Home = lazy(() => import('@/pages/Home'));
const About = lazy(() => import('@/pages/About'));
const Services = lazy(() => import('@/pages/Services'));
const Team = lazy(() => import('@/pages/Team'));
const Contact = lazy(() => import('@/pages/Contact'));

/**
 * ScrollToTop Component
 */
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

/**
 * PageTransition Component
 * Only runs the sweep animation on actual navigation (pathname changes).
 * Never fires during initial mount or while the preloader is active.
 */
function PageTransition({ children, ready }: { children: ReactNode; ready: boolean }) {
  const location = useLocation();
  const containerRef = useRef<HTMLDivElement>(null);
  const sweepRef = useRef<HTMLDivElement>(null);

  // Track whether this is the very first render after mount
  const mountedRef = useRef(false);
  // Track the pathname we last animated for — prevents double-firing
  const lastPathRef = useRef(location.pathname);

  const [displayChildren, setDisplayChildren] = useState(children);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // On first mount: set initial GSAP state, no animation
  useLayoutEffect(() => {
    gsap.set(sweepRef.current, { scaleY: 0 });
    gsap.set(containerRef.current, { opacity: 1, y: 0, filter: 'none' });
    // Mark as mounted after the first layout pass
    mountedRef.current = true;
    lastPathRef.current = location.pathname;
  }, []);

  useEffect(() => {
    // Skip if not ready (preloader still active), not yet mounted, or same path
    if (!ready || !mountedRef.current || location.pathname === lastPathRef.current) return;

    lastPathRef.current = location.pathname;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        onStart: () => setIsTransitioning(true),
        onComplete: () => setIsTransitioning(false),
      });

      // 1. Fade out current content
      tl.to(containerRef.current, {
        y: -20,
        opacity: 0,
        filter: 'blur(8px)',
        duration: 0.35,
        ease: 'power2.in',
      });

      // 2. Orange sweep rises up
      tl.fromTo(
        sweepRef.current,
        { scaleY: 0, transformOrigin: 'bottom' },
        { scaleY: 1, duration: 0.45, ease: 'expo.inOut' },
        '-=0.15'
      );

      // 3. Swap content while screen is covered
      tl.add(() => setDisplayChildren(children));

      // 4. Orange sweep exits upward
      tl.to(sweepRef.current, {
        scaleY: 0,
        transformOrigin: 'top',
        duration: 0.5,
        ease: 'expo.inOut',
      });

      // 5. New content fades in
      tl.fromTo(
        containerRef.current,
        { y: 30, opacity: 0, filter: 'blur(8px)' },
        { y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.65, ease: 'power4.out' },
        '-=0.3'
      );
    }, containerRef);

    return () => ctx.revert();
  }, [location.pathname, ready]);

  // Keep displayChildren in sync when not transitioning
  useEffect(() => {
    if (!isTransitioning) setDisplayChildren(children);
  }, [children, isTransitioning]);

  return (
    <div className="relative w-full overflow-hidden">
      {/* Orange sweep overlay */}
      <div
        ref={sweepRef}
        className="fixed inset-0 z-[70] pointer-events-none origin-bottom"
        style={{ backgroundColor: '#FF6A00', transform: 'scaleY(0)' }}
      />
      <div
        ref={containerRef}
        className={isTransitioning ? 'pointer-events-none' : 'pointer-events-auto'}
      >
        {displayChildren}
      </div>
    </div>
  );
}

// Footer data — defined outside component to avoid recreation on every render
const footerNavLinks = [
  { name: 'Home', href: '/' },
  { name: 'About', href: '/about' },
  { name: 'Services', href: '/services' },
  { name: 'Team', href: '/team' },
  { name: 'Contact', href: '/contact' },
];

const footerSocialLinks = [
  { icon: LinkedinIcon, href: 'https://www.linkedin.com/company/phoenixbrothers/', label: 'LinkedIn' },
  { icon: InstagramIcon, href: 'https://www.instagram.com/phoenixbrothersoff?igsh=MTk1bXI2aGMwcHV2Mg==', label: 'Instagram' },
];

// Computed once at module load — never changes during a session
const CURRENT_YEAR = new Date().getFullYear();

const Footer = memo(function Footer() {
  const scrollToTop = useCallback(() => window.scrollTo({ top: 0, behavior: 'smooth' }), []);
  const navLinks = footerNavLinks;
  const socialLinks = footerSocialLinks;

  return (
    <footer className="relative bg-brand-surface pt-[clamp(1.5rem,4vh,2.5rem)] pb-[clamp(0.5rem,2vh,1rem)] overflow-hidden border-t border-brand-primary/10">
      {/* Premium Decorative Glow */}
      <div className="absolute top-0 right-1/4 w-[clamp(300px,40vw,500px)] h-[clamp(300px,40vw,500px)] bg-brand-primary/5 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-[1400px] mx-auto px-[clamp(1.5rem,4vw,2.5rem)] relative z-10">
        <div className="flex flex-col md:flex-row justify-between gap-[clamp(1.25rem,4vw,2.5rem)] mb-[clamp(1.25rem,4vw,2.5rem)]">
          
          {/* Left Side: Brand & Socials */}
          <div className="flex flex-col gap-[clamp(0.5rem,2vw,1rem)] w-full md:w-[45%]">
            <div className="flex items-center gap-[clamp(0.5rem,2vw,1rem)] group cursor-default">
              <div className="w-[clamp(2rem,5vw,3.25rem)] h-[clamp(2rem,5vw,3.25rem)] rounded-[clamp(0.5rem,2vw,1rem)] bg-brand-primary/10 flex items-center justify-center border border-brand-primary/20 group-hover:border-brand-primary/50 transition-colors shrink-0">
                <img src="/logo.png" alt="Logo" className="w-[clamp(1.2rem,3vw,1.8rem)] h-auto object-contain" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-[clamp(1.1rem,2.5vw,1.4rem)] font-black tracking-tighter uppercase text-brand-text">PHOENIX</span>
                <span className="text-[clamp(0.85rem,2vw,1.1rem)] font-bold tracking-widest uppercase text-brand-primary">BROTHERS</span>
              </div>
            </div>
            <p className="text-brand-text/60 max-w-[45ch] leading-snug text-[clamp(0.85rem,1.5vw,0.95rem)] font-medium">
              Engineering high-performance digital products at the intersection of psychology, strategy, and technology.
            </p>
            <div className="flex space-x-3 pt-1 md:pt-2">
              {socialLinks.map((social, i) => (
                <a key={i} href={social.href} target="_blank" rel="noopener noreferrer" className="w-11 h-11 rounded-full flex items-center justify-center bg-brand-text/5 text-brand-text/60 hover:text-brand-primary hover:bg-brand-primary/10 hover:border-brand-primary/30 transition-all border border-transparent" aria-label={social.label}>
                  <social.icon size={20} />
                </a>
              ))}
            </div>
          </div>

          {/* Right Side: Links & Contact */}
          <div className="flex flex-col sm:flex-row gap-6 sm:gap-[clamp(1.5rem,4vw,3rem)] w-full md:w-[50%]">
            
            {/* Navigation */}
            <div className="flex flex-col gap-2 w-full sm:w-auto">
              <h4 className="text-[10px] uppercase text-brand-text/40 font-black tracking-[0.2em] mb-1">Navigation</h4>
              <ul className="grid grid-cols-2 sm:grid-cols-1 lg:grid-cols-2 gap-y-2 gap-x-6">
                {navLinks.map((link) => (
                  <li key={link.name}>
                    <Link
                      to={link.href}
                      onClick={() => window.scrollTo(0,0)}
                      className="text-[clamp(0.85rem,1.5vw,1rem)] text-brand-text/80 hover:text-brand-primary transition-colors font-bold flex items-center group w-fit"
                    >
                      <span className="w-0 group-hover:w-3 transition-all duration-300 h-[2px] bg-brand-primary mr-0 group-hover:mr-2 rounded-full" />
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact & CTA */}
            <div className="flex flex-col gap-2 w-full sm:w-auto">
              <h4 className="text-[10px] uppercase text-brand-text/40 font-black tracking-[0.2em] mb-1">Connect with us</h4>
              <Link to="/contact#brief" className="inline-block text-[clamp(0.7rem,1.5vw,0.9rem)] break-all font-bold text-brand-text hover:text-brand-primary transition-colors pb-1 border-b border-brand-primary/20 hover:border-brand-primary w-fit underline-offset-4">
                phoenixbrothersofficial@gmail.com
              </Link>
              <div className="mt-3 sm:mt-auto">
                <button onClick={scrollToTop} className="group flex items-center gap-2 text-[10px] font-black tracking-[0.2em] uppercase text-brand-text/50 hover:text-brand-primary transition-all">
                  Back to Top
                  <div className="w-9 h-9 rounded-full border border-brand-text/10 flex items-center justify-center group-hover:bg-brand-primary/10 group-hover:border-brand-primary group-hover:-translate-y-1 transition-all">
                    <ArrowUp size={16} className="text-brand-text/60 group-hover:text-brand-primary" />
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="flex flex-col sm:flex-row justify-between items-center pt-[clamp(0.5rem,2vw,1rem)] border-t border-brand-text/5 gap-1 sm:gap-2">
          <p className="text-brand-text/40 text-[clamp(0.55rem,1.2vw,0.65rem)] font-bold tracking-widest uppercase text-center">
            © {CURRENT_YEAR} Phoenix Brothers. All rights reserved.
          </p>
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-brand-surface via-brand-primary/50 to-brand-surface opacity-30 pointer-events-none" />
        </div>
      </div>
    </footer>
  );
});
Footer.displayName = 'Footer';

export default function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
    });
    const rafId = { current: 0 };
    function raf(time: number) {
      lenis.raf(time);
      rafId.current = requestAnimationFrame(raf);
    }
    rafId.current = requestAnimationFrame(raf);
    return () => {
      cancelAnimationFrame(rafId.current);
      lenis.destroy();
    };
  }, []);

  return (
    <ThemeProvider defaultTheme="light" storageKey="phoenix-theme">
      <Router>
        <ScrollToTop />

        {/* Preloader — unmounts after its own GSAP exit completes */}
        {loading && (
          <Preloader onComplete={() => setLoading(false)} />
        )}

        {/* App shell — always in DOM so Router context is stable,
            but PageTransition only animates once `ready` is true */}
        <div
          className="min-h-screen bg-brand-dark text-brand-text selection:bg-brand-primary selection:text-white"
          style={{ visibility: loading ? 'hidden' : 'visible' }}
        >
          <Navbar />
          <PageTransition ready={!loading}>
            <Suspense fallback={<div className="min-h-screen bg-brand-dark" />}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/about" element={<About />} />
                <Route path="/services" element={<Services />} />
                <Route path="/projects" element={<Navigate to="/services" replace />} />
                <Route path="/team" element={<Team />} />
                <Route path="/contact" element={<Contact />} />
              </Routes>
            </Suspense>
          </PageTransition>
          <Footer />
        </div>
      </Router>
    </ThemeProvider>
  );
}