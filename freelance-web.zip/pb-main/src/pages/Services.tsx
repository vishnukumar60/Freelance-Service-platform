﻿import { memo, useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, animate, useAnimationFrame, LayoutGroup } from 'framer-motion';
import {
  Code, Smartphone, Palette, Cloud, Brain, Target,
  ArrowUpRight, ChevronLeft, ChevronRight, X, Pause, Play, ExternalLink, Info,
} from 'lucide-react';
import { useHoverTilt } from '@/components/animations/GSAPHooks';
import { Link, useLocation } from 'react-router-dom';
import { PageBackground } from '@/components/ui/Layout';

// ─── Services Data ────────────────────────────────────────────────────────────

const sixServices = [
  {
    title: 'Web Engineering',
    desc: 'Scalable, high-performance web applications built for speed, SEO, and modern user demands.',
    details: 'We architect next-generation platforms using micro-frontends, server-side rendering, and edge computing. Our approach ensures lightning-fast load times, superior SEO visibility, and seamless scalability through optimized asset pipelines and modular design systems.',
    icon: Code, tag: 'Architecture',
  },
  {
    title: 'Mobile Solutions',
    desc: 'Seamless, high-performance mobile experiences tailored for iOS and Android ecosystems.',
    details: 'We deliver cross-platform and native mobile applications with a focus on performance, responsiveness, and user engagement. From offline-first data sync to biometric authentication and deep device integration, our solutions ensure reliability and premium user experiences.',
    icon: Smartphone, tag: 'Native',
  },
  {
    title: 'Experience Design',
    desc: 'Human-centered UI/UX design that drives engagement, retention, and business growth.',
    details: 'Our design process blends behavioral psychology, user research, and data insights to craft intuitive interfaces. We create high-fidelity prototypes, conduct usability testing, and refine interactions to deliver experiences that convert and delight users.',
    icon: Palette, tag: 'Design',
  },
  {
    title: 'Cloud Systems',
    desc: 'Robust, scalable cloud infrastructure engineered for reliability and continuous delivery.',
    details: 'We build resilient systems using Kubernetes orchestration, multi-region deployments, and automated CI/CD pipelines. Our cloud strategies ensure high availability, fault tolerance, and effortless scalability for mission-critical applications.',
    icon: Cloud, tag: 'DevOps',
  },
  {
    title: 'Cognitive AI',
    desc: 'AI-powered solutions that automate workflows and unlock intelligent decision-making.',
    details: 'We integrate advanced machine learning models, including custom-trained LLMs and neural networks, to enable predictive analytics, intelligent automation, and real-time insights tailored to your business needs.',
    icon: Brain, tag: 'Intelligence',
  },
  {
    title: 'Strategic Growth',
    desc: 'Data-driven strategies that position your brand for sustained competitive advantage.',
    details: 'We leverage big data, market intelligence, and performance analytics to identify growth opportunities, refine brand positioning, and implement strategies that maximize conversions and long-term impact.',
    icon: Target, tag: 'Strategy',
  },
];

const tripleServices = [...sixServices, ...sixServices, ...sixServices];
const PX_PER_SEC = 40;

// ─── Projects Data ────────────────────────────────────────────────────────────

interface Project {
  title: string; category: string; image: string;
  tech: string[]; link: string; info: string;
}

const projects: Project[] = [
  {
    title: 'Ammakoozhkadai', category: 'Restaurant',
    image: 'https://static.sportzbusiness.com/uploads/2025/11/Fermented-Curd-Rice.jpg',
    tech: ['React', 'Tailwind CSS'], link: 'https://ammakoozhkadai.com/',
    info: 'A full-featured restaurant web presence built for Ammakoozhkadai, showcasing their authentic South Indian menu, location, and brand story. Optimized for mobile-first browsing with fast load times and a warm, inviting visual identity.',
  },
  {
    title: 'Snakes & Ladders', category: 'Gaming',
    image: 'https://c8.alamy.com/comp/RR1AC8/a-snake-ladder-board-game-illustration-RR1AC8.jpg',
    tech: ['HTML', 'Tailwind CSS', 'JavaScript'],
    link: 'https://68af39e8b116f1cb79287efd--deluxe-gnome-b25c32.netlify.app/',
    info: 'A browser-based Snakes & Ladders game built with vanilla JavaScript. Features smooth dice animations, turn-based multiplayer logic, and a fully responsive board that adapts to any screen size — no frameworks, no dependencies.',
  },
  {
    title: 'Aurafix', category: 'SaaS', image: '/aurafix.jpeg',
    tech: ['React', 'Node.js', 'Tailwind CSS'], link: 'https://aurafix.lovable.app',
    info: 'Aurafix is a SaaS platform designed to streamline workflow automation and team productivity. Built with a React frontend and Node.js backend, it features real-time updates, role-based access control, and a clean dashboard interface.',
  },
  {
    title: 'Portfolio', category: 'Fintech', image: '/port.png',
    tech: ['HTML', 'Tailwind CSS', 'JavaScript'], link: 'https://akhilr.web.app/',
    info: 'A personal portfolio site for a backend developer, designed to highlight technical skills, project work, and professional background. Built with pure HTML, Tailwind CSS, and JavaScript for maximum performance and zero overhead.',
  },
  {
    title: 'CostLenz', category: 'FinTech',
    image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=800&q=80',
    tech: ['React', 'Tailwind CSS', 'Lovable'],
    link: 'https://costlenz.lovable.app',
    info: 'CostLenz is a smart expense management system that helps individuals and teams track, categorize, and analyze spending in real time. Built for clarity and speed, it delivers actionable financial insights through a clean, intuitive dashboard.',
  },
  {
    title: 'OnDuty Way', category: 'HR & Admin',
    image: 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?w=800&q=80',
    tech: ['React', 'Tailwind CSS', 'Lovable'],
    link: 'https://onduty-way.lovable.app',
    info: 'OnDuty Way is an online on-duty and leave request management system that streamlines employee absence workflows. It enables staff to submit, track, and get approvals for on-duty assignments and leave applications through a simple, paperless interface.',
  },
];
// ─── Service Detail Strip ─────────────────────────────────────────────────────
// Expands below the carousel as a full-width panel when a service card is clicked.

const ServiceDetailStrip = ({ service, onClose }: { service: any; onClose: () => void }) => {
  useEffect(() => {
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, [onClose]);

  return (
    <motion.div
      key={service.title}
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.42, ease: [0.23, 1, 0.32, 1] }}
      className="overflow-hidden w-full"
    >
      <motion.div
        initial={{ y: -16, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -12, opacity: 0 }}
        transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1], delay: 0.06 }}
        className="mx-[clamp(1rem,4vw,2rem)] mb-6 rounded-[clamp(1.25rem,3vw,2rem)] overflow-hidden border border-brand-primary/25 shadow-[0_8px_48px_rgba(255,106,0,0.1)] bg-brand-graphite"
      >
        {/* Orange top bar */}
        <div className="h-[3px] bg-brand-primary w-full" />

        <div className="flex flex-col md:flex-row">
          {/* Left: icon + title block */}
          <div className="relative bg-brand-primary p-[clamp(1.5rem,4vw,2.5rem)] flex flex-col items-center justify-center gap-3 md:w-[280px] shrink-0 overflow-hidden">
            <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white/5 pointer-events-none" />
            <div className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-black/10 pointer-events-none" />
            <motion.div
              initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.12, duration: 0.32, ease: [0.23, 1, 0.32, 1] }}
              className="relative w-14 h-14 rounded-2xl bg-white/15 border border-white/25 flex items-center justify-center text-white"
            >
              <service.icon size={26} strokeWidth={1.2} />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.16, duration: 0.3 }}
              className="flex flex-col items-center gap-1 text-center"
            >
              <span className="px-2.5 py-0.5 rounded-full bg-white/15 border border-white/20 text-white/80 font-black text-[0.52rem] tracking-[0.3em] uppercase">
                {service.tag}
              </span>
              <h2 className="text-[clamp(1.25rem,3.5vw,2rem)] font-black text-white tracking-tighter uppercase leading-[0.9]">
                {service.title}
              </h2>
            </motion.div>
          </div>

          {/* Right: details */}
          <div className="flex flex-col gap-4 p-[clamp(1.25rem,4vw,2rem)] flex-1 relative">
            {/* Close */}
            <button onClick={onClose} aria-label="Close"
              className="absolute top-3 right-3 w-8 h-8 rounded-full bg-brand-sand/8 border border-brand-sand/10 flex items-center justify-center text-brand-sand/40 hover:text-brand-primary hover:border-brand-primary hover:bg-brand-primary/10 active:scale-95 transition-all duration-200">
              <X size={13} />
            </button>

            <p className="text-brand-sand/70 text-[clamp(0.82rem,1.8vw,0.95rem)] leading-relaxed font-medium pr-8">
              {service.details}
            </p>

            <div className="h-px bg-brand-sand/10" />

            <div className="flex items-center justify-between gap-4 flex-wrap">
              <p className="text-brand-sand/40 text-[0.72rem] font-medium leading-relaxed max-w-[36ch] hidden sm:block">
                {service.desc}
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

// ─── Service Card ─────────────────────────────────────────────────────────────

const ServiceCard = memo(({ service, index, isActive, onToggle }: {
  service: any; index: number; isActive: boolean; onToggle: (s: any) => void;
}) => {
  const num = String((index % sixServices.length) + 1).padStart(2, '0');

  return (
    <div className="w-[clamp(280px,82vw,320px)] md:w-[clamp(300px,40vw,380px)] shrink-0 px-[clamp(0.5rem,1.5vw,0.75rem)] group select-none">
      <motion.div
        whileHover={{ y: isActive ? 0 : -5 }}
        transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
        className={[
          'relative h-[clamp(280px,48vw,360px)] md:h-[clamp(340px,52vh,420px)] w-full bg-brand-graphite',
          'rounded-[clamp(1.25rem,3vw,2rem)] overflow-hidden flex flex-col',
          'border transition-colors duration-500',
          isActive
            ? 'border-brand-primary/50 shadow-[0_0_32px_rgba(255,106,0,0.15)]'
            : 'border-brand-sand/5 group-hover:border-brand-primary/30',
        ].join(' ')}
      >
        {/* Active indicator bar */}
        <AnimatePresence>
          {isActive && (
            <motion.div
              initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} exit={{ scaleX: 0 }}
              transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
              className="absolute top-0 left-0 right-0 h-[3px] bg-brand-primary origin-left z-10"
            />
          )}
        </AnimatePresence>

        {/* Hover gradient */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 80% 60% at 50% 120%, rgba(255,106,0,0.12) 0%, transparent 70%)' }} />

        <div className="p-[clamp(1rem,3.5vw,1.75rem)] flex flex-col flex-grow relative z-10">
          <div className="flex justify-between items-start mb-auto">
            <div className={[
              'w-11 h-11 md:w-12 md:h-12 rounded-xl border flex items-center justify-center transition-all duration-500 shrink-0',
              isActive
                ? 'bg-brand-primary/15 border-brand-primary/50 text-brand-primary'
                : 'bg-brand-ink border-brand-sand/10 text-brand-sand/40 group-hover:text-brand-primary group-hover:border-brand-primary/40 group-hover:bg-brand-primary/10',
            ].join(' ')}>
              <service.icon size={20} strokeWidth={1.3} />
            </div>
            <span className={[
              'font-mono text-[0.52rem] tracking-[0.25em] font-bold uppercase transition-colors duration-500',
              isActive ? 'text-brand-primary/70' : 'text-brand-sand/20 group-hover:text-brand-primary/60',
            ].join(' ')}>
              {num}
            </span>
          </div>

          <div className="flex flex-col gap-2.5 mt-auto">
            <span className="inline-flex w-fit px-2 py-0.5 rounded-full bg-brand-primary/10 border border-brand-primary/20 text-brand-primary text-[0.48rem] font-black uppercase tracking-widest">
              {service.tag}
            </span>
            <h3 className="text-[clamp(1.25rem,3.5vw,1.875rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[0.92]">
              {service.title.split(' ')[0]}
              <br />
              <span className={isActive ? 'text-brand-ivory/80' : 'text-brand-sand/25 group-hover:text-brand-ivory/70 transition-colors duration-500'}>
                {service.title.split(' ').slice(1).join(' ')}
              </span>
            </h3>
            <p className="text-brand-sand/50 text-[0.78rem] leading-relaxed max-w-[26ch] opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-75 hidden md:block">
              {service.desc}
            </p>
          </div>
        </div>

        {/* Bottom bar — click target for toggle */}
        <div
          onClick={() => onToggle(service)}
          className={[
            'flex justify-between items-center px-[clamp(1rem,3.5vw,1.75rem)] py-4 border-t transition-colors duration-500 relative z-10 cursor-pointer',
            isActive ? 'bg-brand-primary/8 border-brand-primary/20' : 'bg-brand-surface border-brand-sand/5 hover:bg-brand-primary/5',
          ].join(' ')}
        >
          <span className={[
            'text-[0.52rem] font-black uppercase tracking-[0.2em] transition-colors duration-500',
            isActive ? 'text-brand-primary' : 'text-brand-sand/20 group-hover:text-brand-primary',
          ].join(' ')}>
            {isActive ? 'Collapse' : 'Learn More'}
          </span>
          <motion.div
            animate={{ rotate: isActive ? 45 : 0 }}
            transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
            className={[
              'w-8 h-8 md:w-9 md:h-9 rounded-full flex items-center justify-center transition-all duration-500 shrink-0',
              isActive ? 'bg-brand-primary text-white' : 'bg-brand-sand/5 text-brand-sand/20 group-hover:bg-brand-primary group-hover:text-white',
            ].join(' ')}
          >
            <ArrowUpRight size={15} />
          </motion.div>
        </div>

        <div className="absolute inset-0 rounded-[inherit] ring-1 ring-inset ring-brand-primary/0 group-hover:ring-brand-primary/25 transition-all duration-500 pointer-events-none" />
        <div className="absolute bottom-0 left-[10%] right-[10%] h-px bg-brand-primary/0 group-hover:bg-brand-primary/40 transition-all duration-700 pointer-events-none" />
      </motion.div>
    </div>
  );
});
ServiceCard.displayName = 'ServiceCard';
// ─── Project Card (self-expanding) ───────────────────────────────────────────
// Expands in-place within the grid using Framer Motion shared layout animation.
// Collapsed: 4/3 image card. Expanded: spans full grid width with detail panel.

const ProjectCard = memo(({ project, index, expandedId, onExpand }: {
  project: Project;
  index: number;
  expandedId: string | null;
  onExpand: (id: string | null) => void;
}) => {
  const tiltRef = useHoverTilt();
  const cardRef = useRef<HTMLDivElement>(null);
  const [hovered, setHovered] = useState(false);
  const [spotlight, setSpotlight] = useState({ x: 50, y: 50 });
  const isExpanded = expandedId === project.title;
  const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

  // Escape to collapse
  useEffect(() => {
    if (!isExpanded) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onExpand(null); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [isExpanded, onExpand]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current || isExpanded) return;
    const r = cardRef.current.getBoundingClientRect();
    setSpotlight({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 });
  }, [isExpanded]);

  const showActions = !isExpanded && (isTouch || hovered);

  return (
    <motion.div
      layout
      layoutId={`proj-wrap-${project.title}`}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ layout: { duration: 0.45, ease: [0.23, 1, 0.32, 1] }, opacity: { duration: 0.5, delay: index * 0.07 }, y: { duration: 0.5, delay: index * 0.07 } }}
      // Expanded card spans both columns on sm+
      className={isExpanded ? 'col-span-1 sm:col-span-2' : 'col-span-1'}
    >
      <motion.div
        layout
        layoutId={`proj-card-${project.title}`}
        ref={(el) => { (tiltRef as any).current = isExpanded ? null : el; (cardRef as any).current = el; }}
        transition={{ layout: { duration: 0.45, ease: [0.23, 1, 0.32, 1] } }}
        className={[
          'relative overflow-hidden rounded-2xl md:rounded-3xl border group',
          isExpanded
            ? 'border-brand-primary/35 shadow-[0_4px_40px_rgba(255,106,0,0.12)] bg-brand-graphite cursor-default'
            : 'border-white/5 cursor-default',
        ].join(' ')}
        onMouseEnter={() => { if (!isExpanded) setHovered(true); }}
        onMouseLeave={() => setHovered(false)}
        onMouseMove={handleMouseMove}
      >
        <AnimatePresence mode="wait" initial={false}>
          {!isExpanded ? (
            /* ── COLLAPSED: image card ─────────────────────────── */
            <motion.div
              key="collapsed"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative aspect-[4/3]"
            >
              <img src={project.image} alt={project.title}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110 grayscale group-hover:grayscale-0"
                loading="lazy" />

              {/* Cursor spotlight */}
              {!isTouch && (
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{ background: `radial-gradient(circle 200px at ${spotlight.x}% ${spotlight.y}%, rgba(255,106,0,0.18) 0%, transparent 70%)` }} />
              )}

              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/25 to-transparent" />

              {/* Index */}
              <div className="absolute top-3 left-3 z-10">
                <span className="font-mono text-[0.52rem] font-bold tracking-[0.28em] text-white/25 group-hover:text-brand-primary/80 transition-colors duration-500">
                  {String(index + 1).padStart(2, '0')}
                </span>
              </div>

              {/* Bottom content */}
              <div className="absolute bottom-0 left-0 right-0 z-10 px-[clamp(0.75rem,2.5vw,1.25rem)] pb-[clamp(0.75rem,2.5vw,1.25rem)] pt-8">
                <h3 className="text-[clamp(0.9rem,2.5vw,1.5rem)] font-black tracking-tight text-white leading-tight mb-1.5">
                  {project.title}
                </h3>
                <div className="flex flex-wrap gap-1 mb-2.5">
                  {project.tech.map((t) => (
                    <span key={t} className="px-1.5 py-0.5 bg-white/10 backdrop-blur-md border border-white/10 rounded-full text-[clamp(0.4rem,1vw,0.55rem)] text-white/70 font-medium">
                      {t}
                    </span>
                  ))}
                </div>
                <motion.div
                  initial={false}
                  animate={{ opacity: showActions ? 1 : 0, y: showActions ? 0 : 10 }}
                  transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
                  className="flex items-center justify-end gap-2"
                >
                  <button
                    onClick={(e) => { e.stopPropagation(); onExpand(project.title); }}
                    aria-label={`Details for ${project.title}`}
                    className="w-9 h-9 rounded-full bg-white/10 backdrop-blur-md border border-white/15 flex items-center justify-center text-white/70 hover:bg-brand-primary hover:border-brand-primary hover:text-white active:scale-95 transition-all duration-300 touch-manipulation"
                  >
                    <Info size={14} strokeWidth={2} />
                  </button>
                  <a href={project.link} target="_blank" rel="noopener noreferrer" aria-label={`Visit ${project.title}`}
                    className="w-9 h-9 rounded-full bg-brand-primary flex items-center justify-center text-white shadow-lg active:scale-95 transition-all duration-300 touch-manipulation">
                    <ExternalLink size={14} strokeWidth={2.5} />
                  </a>
                </motion.div>
              </div>

              <div className="absolute inset-0 rounded-2xl md:rounded-3xl ring-1 ring-inset ring-brand-primary/0 group-hover:ring-brand-primary/30 transition-all duration-500 pointer-events-none" />
            </motion.div>

          ) : (
            /* ── EXPANDED: detail panel ────────────────────────── */
            <motion.div
              key="expanded"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.22 }}
              className="flex flex-col sm:flex-row min-h-[220px]"
            >
              {/* Image panel */}
              <div className="relative sm:w-[42%] shrink-0 overflow-hidden" style={{ minHeight: '180px' }}>
                <img src={project.image} alt={project.title}
                  className="w-full h-full object-cover" style={{ minHeight: '180px' }} />
                <div className="absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-brand-graphite via-brand-graphite/20 to-transparent" />
                <div className="absolute bottom-3 left-3">
                  <span className="inline-flex px-2 py-0.5 rounded-full bg-brand-primary/90 text-white font-black text-[0.48rem] tracking-[0.28em] uppercase">
                    {project.category}
                  </span>
                </div>
                <div className="absolute top-3 left-3">
                  <span className="font-mono text-[0.5rem] font-bold tracking-[0.28em] text-white/30">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                </div>
              </div>

              {/* Detail panel */}
              <div className="relative flex flex-col gap-3 p-[clamp(1rem,3vw,1.5rem)] flex-1 bg-brand-graphite">
                {/* Orange accent */}
                <div className="absolute top-0 left-0 right-0 h-[3px] sm:h-auto sm:top-0 sm:bottom-0 sm:left-0 sm:w-[3px] sm:right-auto bg-brand-primary" />

                {/* Close */}
                <button onClick={() => onExpand(null)} aria-label="Collapse"
                  className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-brand-sand/8 border border-brand-sand/10 flex items-center justify-center text-brand-sand/40 hover:text-brand-primary hover:border-brand-primary hover:bg-brand-primary/10 active:scale-95 transition-all duration-200 touch-manipulation">
                  <X size={13} />
                </button>

                <h3 className="text-[clamp(1rem,3vw,1.5rem)] font-black text-brand-ivory tracking-tighter uppercase leading-tight pr-10">
                  {project.title}
                </h3>

                <div className="h-px bg-brand-sand/10 shrink-0" />

                <p className="text-brand-sand/70 text-[clamp(0.72rem,1.6vw,0.85rem)] leading-relaxed font-medium flex-1">
                  {project.info}
                </p>

                <div className="flex flex-wrap gap-1.5">
                  {project.tech.map((t) => (
                    <span key={t} className="px-2 py-0.5 bg-brand-ink border border-brand-sand/10 rounded-full text-[clamp(0.44rem,1vw,0.56rem)] text-brand-sand/60 font-medium">
                      {t}
                    </span>
                  ))}
                </div>

                <a href={project.link} target="_blank" rel="noopener noreferrer"
                  className="group relative flex items-center justify-center gap-2 w-full py-2.5 bg-brand-primary text-white font-black rounded-full text-[0.58rem] tracking-[0.2em] uppercase overflow-hidden active:scale-95 transition-transform duration-200 touch-manipulation">
                  <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                  <span className="relative z-10">Visit Project</span>
                  <ArrowUpRight size={12} className="relative z-10 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
});
ProjectCard.displayName = 'ProjectCard';
// ─── Main Page ────────────────────────────────────────────────────────────────

export default function Services() {
  const x            = useMotionValue(0);
  const isDragging   = useRef(false);
  const [isPaused, setIsPaused] = useState(false);
  const isPausedRef  = useRef(false);
  // cardWidthRef drives the loop — never stored in state to avoid re-renders
  const cardWidthRef = useRef(340);
  const loopRef      = useRef(340 * sixServices.length);
  const rulerRef     = useRef<HTMLDivElement>(null);

  // Active service: the service whose detail strip is open
  const [activeService, setActiveService] = useState<any | null>(null);
  // Expanded project id
  const [expandedProject, setExpandedProject] = useState<string | null>(null);

  // ── Scroll-to-projects after page transition completes ──────────────────────
  // When navigating from Home via "View Work" (/services#projects), the GSAP
  // page sweep takes ~1.5s. We wait for it to finish then scroll to #projects
  // so Lenis picks it up smoothly with no layout jump.
  const location = useLocation();
  useEffect(() => {
    if (location.hash !== '#projects') return;
    const id = setTimeout(() => {
      const el = document.getElementById('projects');
      if (!el) return;
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 1550);
    return () => clearTimeout(id);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // intentionally runs once on mount — hash is stable for this navigation

  const handleServiceToggle = useCallback((service: any) => {
    setActiveService((prev: any) => prev?.title === service.title ? null : service);
  }, []);

  const handleProjectExpand = useCallback((id: string | null) => {
    setExpandedProject(id);
  }, []);

  // ResizeObserver updates refs only — no setState, no re-render, no jitter
  useEffect(() => {
    if (!rulerRef.current) return;
    const obs = new ResizeObserver(([entry]) => {
      const w = entry.contentRect.width;
      cardWidthRef.current = w;
      loopRef.current = w * sixServices.length;
    });
    obs.observe(rulerRef.current);
    return () => obs.disconnect();
  }, []);

  // Frame loop reads from refs — never stale, never triggers re-render
  useAnimationFrame((_t, delta) => {
    const loop = loopRef.current;
    if (!loop || isDragging.current || isPausedRef.current) return;
    let newX = x.get() - PX_PER_SEC * (Math.min(delta, 64) / 1000);
    if (newX <= -loop) newX += loop;
    else if (newX > 0) newX -= loop;
    x.set(newX);
  });

  const togglePause = useCallback(() => {
    setIsPaused(p => { isPausedRef.current = !p; return !p; });
  }, []);

  const onDragStart = useCallback(() => { isDragging.current = true; }, []);
  const onDragEnd   = useCallback(() => {
    isDragging.current = false;
    const loop = loopRef.current;
    if (!loop) return;
    let cur = x.get();
    while (cur > 0) cur -= loop;
    while (cur <= -loop) cur += loop;
    x.set(cur);
  }, [x]);

  const goNext = useCallback(() => {
    isDragging.current = true;
    animate(x, x.get() - cardWidthRef.current, { duration: 0.45, ease: [0.23, 1, 0.32, 1], onComplete: onDragEnd });
  }, [x, onDragEnd]);
  const goPrev = useCallback(() => {
    isDragging.current = true;
    animate(x, x.get() + cardWidthRef.current, { duration: 0.45, ease: [0.23, 1, 0.32, 1], onComplete: onDragEnd });
  }, [x, onDragEnd]);

  return (
    <main className="relative bg-brand-ink min-h-screen overflow-x-hidden">
      <PageBackground />

      {/* ── SERVICES SECTION ─────────────────────────────────────── */}
      <section className="relative pt-[clamp(5rem,12vh,8rem)] pb-[clamp(2.5rem,6vh,5rem)] flex flex-col">
        <div ref={rulerRef} className="absolute invisible pointer-events-none w-[clamp(280px,82vw,320px)] md:w-[clamp(300px,40vw,380px)]" />

        {/* Header */}
        <div className="max-w-[1400px] w-full mx-auto px-[clamp(1rem,4vw,2rem)] mb-[clamp(2rem,5vh,4rem)] relative z-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
              <div className="flex items-center gap-3 mb-[clamp(0.5rem,2vh,1rem)]">
                <div className="h-px w-8 bg-brand-primary shrink-0" />
                <span className="text-brand-primary font-black text-[clamp(0.48rem,1.4vw,0.6rem)] tracking-[0.45em] uppercase">Core Capabilities</span>
              </div>
              <h1 className="text-[clamp(2.5rem,7vw,5.5rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[0.9]">
                Precision <br /><span className="text-brand-sand/20">Engineering.</span>
              </h1>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.1 }}
              className="flex items-center gap-2.5 shrink-0 self-start sm:self-auto">
              <button onClick={goPrev} aria-label="Previous"
                className="w-10 h-10 md:w-11 md:h-11 rounded-full border border-brand-sand/10 flex items-center justify-center text-brand-ivory hover:border-brand-primary hover:text-brand-primary hover:bg-brand-primary/10 active:scale-95 transition-all duration-300 touch-manipulation">
                <ChevronLeft size={17} />
              </button>
              <button onClick={togglePause} aria-label={isPaused ? 'Resume' : 'Pause'}
                className="w-10 h-10 md:w-11 md:h-11 rounded-full border border-brand-sand/10 flex items-center justify-center text-brand-ivory hover:border-brand-primary hover:text-brand-primary hover:bg-brand-primary/10 active:scale-95 transition-all duration-300 touch-manipulation">
                {isPaused ? <Play size={14} /> : <Pause size={14} />}
              </button>
              <button onClick={goNext} aria-label="Next"
                className="w-10 h-10 md:w-11 md:h-11 rounded-full border border-brand-sand/10 flex items-center justify-center text-brand-ivory hover:border-brand-primary hover:text-brand-primary hover:bg-brand-primary/10 active:scale-95 transition-all duration-300 touch-manipulation">
                <ChevronRight size={17} />
              </button>
            </motion.div>
          </div>
        </div>

        {/* Carousel */}
        <div className="relative z-10 w-full overflow-hidden">
          <div className="absolute left-0 top-0 bottom-0 w-12 md:w-20 bg-gradient-to-r from-brand-ink to-transparent z-20 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-12 md:w-20 bg-gradient-to-l from-brand-ink to-transparent z-20 pointer-events-none" />
          <motion.div
            className="flex will-change-transform items-stretch"
            style={{ x, cursor: 'grab' }}
            drag="x" dragConstraints={{ left: -Infinity, right: Infinity }}
            dragElastic={0} dragMomentum={false}
            whileDrag={{ cursor: 'grabbing' }}
            onDragStart={onDragStart} onDragEnd={onDragEnd}
          >
            {tripleServices.map((service, i) => (
              <ServiceCard
                key={`${service.title}-${i}`}
                service={service} index={i}
                isActive={activeService?.title === service.title}
                onToggle={handleServiceToggle}
              />
            ))}
          </motion.div>
        </div>

        {/* Dot indicators */}
        <div className="flex items-center justify-center gap-2 mt-5 relative z-10">
          {sixServices.map((_, i) => (
            <button key={i} aria-label={`Go to ${sixServices[i].title}`}
              onClick={() => { isDragging.current = true; animate(x, -(cardWidthRef.current * i), { duration: 0.55, ease: [0.23, 1, 0.32, 1], onComplete: onDragEnd }); }}
              className="w-1.5 h-1.5 rounded-full bg-brand-sand/20 hover:bg-brand-primary/60 transition-all duration-300 touch-manipulation" />
          ))}
        </div>

        {/* Service detail strip — expands below carousel */}
        <div className="max-w-[1400px] w-full mx-auto relative z-10 mt-2">
          <AnimatePresence mode="wait">
            {activeService && (
              <ServiceDetailStrip
                key={activeService.title}
                service={activeService}
                onClose={() => setActiveService(null)}
              />
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* ── DIVIDER ──────────────────────────────────────────────── */}
      <div className="max-w-[1400px] mx-auto px-[clamp(1rem,4vw,2rem)] py-2">
        <div className="h-px bg-gradient-to-r from-transparent via-brand-primary/20 to-transparent" />
      </div>

      {/* ── PROJECTS SECTION ─────────────────────────────────────── */}
      <section id="projects" className="relative pt-[clamp(2.5rem,6vh,5rem)] pb-[clamp(4rem,10vh,8rem)]">
        <div className="max-w-[1400px] mx-auto px-[clamp(1rem,4vw,2rem)] relative z-10">

          {/* Header */}
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-[clamp(1.75rem,5vh,4rem)]">
            <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
              <div className="flex items-center gap-3 mb-[clamp(0.5rem,2vh,1rem)]">
                <div className="h-px w-8 bg-brand-primary shrink-0" />
                <span className="text-brand-primary font-black text-[clamp(0.48rem,1.4vw,0.6rem)] tracking-[0.45em] uppercase">Selected Portfolio</span>
              </div>
              <h2 className="text-[clamp(2.25rem,7vw,5.5rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[0.9]">
                Selected <br /><span className="text-brand-sand/20">Works.</span>
              </h2>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }}
              className="hidden lg:flex flex-col gap-4 max-w-[280px]">
              <p className="text-brand-sand/40 text-[clamp(0.9rem,1.8vw,1.05rem)] font-medium leading-relaxed border-l border-brand-sand/10 pl-5">
                We blend aesthetic excellence with technical precision to build digital products that move the needle.
              </p>
              <Link to="/contact"
                className="group relative w-fit flex items-center gap-2 px-5 py-2.5 bg-brand-primary text-white font-black rounded-full text-[0.62rem] tracking-[0.2em] uppercase hover:scale-105 active:scale-95 transition-transform duration-300 overflow-hidden">
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                <span className="relative z-10">Start a Project</span>
                <ArrowUpRight size={12} className="relative z-10 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
              </Link>
            </motion.div>
          </div>

          {/* Projects grid — layout-animated, 1 col mobile / 2 col sm+ */}
          <LayoutGroup>
            <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 gap-[clamp(0.75rem,2.5vw,1.75rem)] w-full max-w-[960px] mx-auto">
              {projects.map((project, i) => (
                <ProjectCard
                  key={project.title}
                  project={project} index={i}
                  expandedId={expandedProject}
                  onExpand={handleProjectExpand}
                />
              ))}
            </motion.div>
          </LayoutGroup>

          {/* Mobile CTA */}
          <motion.div
            initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.2 }}
            className="flex lg:hidden justify-center mt-[clamp(1.5rem,4vh,3rem)]"
          >
            <Link to="/contact"
              className="group relative flex items-center gap-2 px-6 py-3 bg-brand-primary text-white font-black rounded-full text-[0.7rem] tracking-[0.15em] uppercase hover:scale-105 active:scale-95 transition-transform duration-300 overflow-hidden touch-manipulation">
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              <span className="relative z-10">Start a Project</span>
              <ArrowUpRight size={13} className="relative z-10 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
            </Link>
          </motion.div>
        </div>
      </section>
    </main>
  );
}