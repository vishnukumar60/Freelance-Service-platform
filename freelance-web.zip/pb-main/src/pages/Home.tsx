﻿import { motion, useScroll, useTransform } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { Suspense, lazy, memo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight, Zap, Shield, Globe, Cpu } from 'lucide-react';
import { Section, PageBackground } from '@/components/ui/Layout';

const ParticleField = lazy(() => import('@/components/three/ParticleField'));

const features = [
  { title: 'Future-Proof Tech', desc: 'We leverage cutting-edge frameworks and AI to build scalable solutions.', icon: Cpu },
  { title: 'Global Scale', desc: 'Our infrastructure is built to handle millions of users worldwide.', icon: Globe },
  { title: 'Ironclad Security', desc: 'Security is not an afterthought; it is baked into every line of code.', icon: Shield },
  { title: 'Performance First', desc: 'Blazing fast load times and smooth interactions are our standard.', icon: Zap },
];

// Feature card memoized — never re-renders after mount
const FeatureCard = memo(({ feature, i }: { feature: typeof features[0]; i: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ delay: i * 0.1, duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
    className="group relative p-[clamp(1.25rem,3vw,2.5rem)] bg-brand-graphite rounded-[clamp(1rem,3vw,2rem)] border border-brand-sand/5 hover:border-brand-primary/30 transition-colors duration-500 overflow-hidden flex flex-col justify-start"
  >
    <div className="w-[clamp(2.5rem,6vw,3.5rem)] h-[clamp(2.5rem,6vw,3.5rem)] bg-brand-ink rounded-[clamp(0.5rem,1.5vw,1rem)] flex items-center justify-center mb-[clamp(0.75rem,2vh,2rem)] text-brand-sand/20 group-hover:text-brand-primary group-hover:bg-brand-primary/10 transition-all duration-500 border border-brand-sand/5">
      <feature.icon strokeWidth={1.5} className="w-[clamp(1rem,3vw,1.75rem)] h-auto" />
    </div>
    <div>
      <h3 className="text-[clamp(0.85rem,2.5vw,1.25rem)] font-black text-brand-primary mb-[clamp(0.25rem,1vh,1rem)] tracking-tight uppercase group-hover:translate-x-1 transition-transform duration-500 line-clamp-2">
        {feature.title}
      </h3>
      <p className="text-[clamp(0.65rem,1.5vw,0.875rem)] text-brand-sand/40 leading-relaxed font-medium line-clamp-4">
        {feature.desc}
      </p>
    </div>
  </motion.div>
));
FeatureCard.displayName = 'FeatureCard';

const Home = memo(() => {
  const heroRef = useRef<HTMLElement>(null);
  // Compute DPR cap once on mount — avoids reading window.innerWidth every render
  const dprCap = useRef(typeof window !== 'undefined' && window.innerWidth < 768 ? 1.5 : 2);

  // Scope scroll tracking to the hero section only — avoids global scroll listener
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const yText        = useTransform(scrollYProgress, [0, 1], [0, 120]);
  const opacityHero  = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  return (
    <main
      className="relative w-full bg-brand-dark selection:bg-brand-primary/30 overflow-hidden"
    >
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-[85svh] md:min-h-[100svh] w-full flex items-center justify-center overflow-hidden py-32 md:py-0">
        <motion.div
          style={{ opacity: opacityHero }}
          className="absolute inset-0 z-0 bg-gradient-to-b from-transparent to-brand-background/20"
        >
          <Canvas
            camera={{ position: [0, 0, 8], fov: 45 }}
            dpr={[1, dprCap.current]}
            gl={{ antialias: false, alpha: true, powerPreference: 'high-performance' }}
            className="pointer-events-none"
          >
            <Suspense fallback={null}>
              <ParticleField />
            </Suspense>
          </Canvas>
        </motion.div>

        <motion.div
          style={{ y: yText }}
          className="relative z-10 text-center px-[clamp(1rem,4vw,2rem)] max-w-7xl mx-auto w-full"
        >
          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="text-[clamp(2.5rem,6.5vw,5rem)] md:text-[clamp(2.5rem,6.5vw,5rem)] font-black tracking-tighter mb-[clamp(1rem,3vh,2rem)] leading-[0.85] uppercase"
          >
            <span className="block md:inline">We</span>
            <span className="hidden md:inline"> </span>
            <span className="block md:inline">build</span>
            <span className="hidden md:inline"> </span>
            <span className="block md:inline">what</span>
            <br className="hidden md:block" />
            <span className="block md:inline text-brand-primary italic">others</span>
            <span className="hidden md:inline"> </span>
            <span className="block md:inline text-brand-primary italic">imagine</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1 }}
            className="text-[clamp(0.9rem,2vw,1.25rem)] text-brand-text/70 max-w-[50ch] mx-auto mb-[clamp(2rem,5vh,3rem)] px-4"
          >
            We fuse advanced technology, strategic thinking, and refined design to build scalable, future-ready solutions.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-row items-center justify-center gap-[clamp(0.5rem,2vw,1.5rem)] w-full"
          >
            <Link
              to="/contact"
              className="group relative px-[clamp(0.75rem,2vw,2.5rem)] sm:px-[clamp(1.5rem,4vw,2.5rem)] py-[clamp(0.75rem,2vw,1.25rem)] bg-brand-primary text-white font-black rounded-full overflow-hidden transition-transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2 flex-1 sm:flex-none"
            >
              <span className="relative z-10 tracking-widest sm:tracking-[0.2em] text-[clamp(0.5rem,1.5vw,0.75rem)] whitespace-nowrap">START PROJECT</span>
              <div className="absolute inset-0 bg-white/30 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
            </Link>

            <Link
              to="/services#projects"
              className="group relative px-[clamp(0.75rem,2vw,2.5rem)] sm:px-[clamp(1.5rem,4vw,2.5rem)] py-[clamp(0.75rem,2vw,1.25rem)] bg-brand-primary text-white font-black rounded-full overflow-hidden transition-transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2 flex-1 sm:flex-none"
            >
              <span className="relative z-10 tracking-widest sm:tracking-[0.2em] text-[clamp(0.5rem,1.5vw,0.75rem)] whitespace-nowrap">VIEW WORK</span>
              <ArrowUpRight size={14} className="relative z-10 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
              <div className="absolute inset-0 bg-white/30 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
            </Link>
          </motion.div>
        </motion.div>
      </section>

      {/* Features */}
      <Section className="relative pt-[clamp(2.5rem,6vh,10rem)] pb-[clamp(5rem,15vh,10rem)] z-10 border-t border-brand-sand/5">
        <PageBackground />
        <div className="container mx-auto px-[clamp(1.5rem,4vw,2rem)] max-w-7xl">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-[clamp(1rem,4vw,4rem)] mb-[clamp(2rem,6vh,6rem)]">
            <div className="max-w-3xl">
              
             <div className="flex items-center gap-4 text-brand-primary font-black text-[clamp(0.5rem,1.5vw,0.625rem)] tracking-[0.5em] uppercase mb-[clamp(1rem,3vh,1.5rem)]">
  <div className="h-px w-8 bg-brand-primary shrink-0" />
  <span>Capabilities</span>
</div>
              <h2 className="text-[clamp(3rem,8vw,5.5rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[0.9]">
                Engineered for <br />
                <span className="text-brand-sand/20">Absolute Scale.</span>
              </h2>
            </div>
            <div className="lg:pb-2 text-left lg:text-right max-w-sm">
              <p className="text-brand-sand/40 font-medium italic text-[clamp(0.875rem,2vw,1.125rem)] leading-relaxed">
                "We don't just ship code. We deploy competitive advantages."
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-[clamp(0.75rem,2vw,1.5rem)]">
            {features.map((feature, i) => (
              <FeatureCard key={feature.title} feature={feature} i={i} />
            ))}
          </div>
        </div>
      </Section>

    </main>
  );
});

Home.displayName = 'Home';
export default Home;