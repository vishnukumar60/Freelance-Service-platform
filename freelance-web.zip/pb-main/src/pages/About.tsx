﻿import { memo, useEffect, useRef } from "react";
import { Target, Eye, Zap, ArrowUpRight } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { PageBackground } from "@/components/ui/Layout";

const values = [
  {
    icon: Target,
    title: "Mission-Driven",
    description: "Every line of code serves a purpose — delivering reliable, scalable SaaS that moves the needle.",
  },
  {
    icon: Eye,
    title: "Human-Centered",
    description: "We combine robust engineering with elegant UX to create products that feel as good as they perform.",
  },
  {
    icon: Zap,
    title: "Innovation First",
    description: "Our proprietary frameworks cut time to market by 40%, keeping you ahead of the curve.",
  },
];

const stats = [
  { value: "40%",  label: "Faster Delivery" },
  { value: "6+",   label: "Core Engineers" },
  { value: "100%", label: "Client Retention" },
  { value: "24h",  label: "Response Time" },
];

const pillars = [
  { t: "Customer-Centric",     d: "Every solution starts with your specific needs." },
  { t: "Scalability",          d: "Systems built to grow seamlessly with you." },
  { t: "Reliability",          d: "Engineered for stability under real-world demands." },
  { t: "Continuous Evolution", d: "Evolving solutions to keep you ahead." },
];

const feedImages = ["/lab1.jpg", "/lab2.jpg", "/lab3.jpg", "/lab4.jpg", "/lab5.jpg"];

/* ── Visual Feed ─────────────────────────────────────────────────── */
const VisualFeed = memo(({ isMobile = false }: { isMobile?: boolean }) => {
  const feedRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = feedRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { el.style.animationPlayState = entry.isIntersecting ? "running" : "paused"; },
      { threshold: 0 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  if (isMobile) {
    return (
      <div className="w-full overflow-hidden">
        <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar snap-x snap-mandatory">
          {feedImages.map((src, idx) => (
            <div
              key={idx}
              className="relative w-[80vw] max-w-[320px] aspect-[4/3] rounded-2xl overflow-hidden border border-brand-sand/10 snap-center shadow-lg shrink-0"
            >
              <img
                src={src}
                alt="Lab"
                className="w-full h-full object-cover opacity-80"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-ink/60 to-transparent" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full overflow-hidden pointer-events-none flex flex-col">
      <div
        ref={feedRef}
        className="flex flex-col will-change-transform"
        style={{ animation: "scrollVertical 40s linear infinite" }}
      >
        {[0, 1].map((set) => (
          <div key={set} className="flex flex-col gap-5 pb-5 w-full">
            {feedImages.map((src, idx) => (
              <div
                key={`${set}-${idx}`}
                className="relative w-full aspect-[4/3] rounded-[2rem] overflow-hidden border border-brand-sand/10 shrink-0 bg-brand-ink/50"
              >
                <img
                  src={src}
                  alt="Work"
                  className="w-full h-full object-cover opacity-75 hover:opacity-90 transition-opacity duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-ink/50 to-transparent" />
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
});

VisualFeed.displayName = "VisualFeed";

/* ── Page ────────────────────────────────────────────────────────── */
export default function About() {
  return (
    <main className="min-h-screen bg-brand-ink text-brand-ivory overflow-x-hidden">
      <PageBackground />

      <div className="relative z-10 max-w-[1400px] mx-auto px-[clamp(1rem,5vw,2.5rem)] pt-[clamp(5rem,12vh,10rem)] pb-[clamp(3rem,8vh,8rem)]">

        {/* ── HEADER ─────────────────────────────────────────────── */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-[clamp(2rem,6vh,6rem)]">
          <div>
            {/* Eyebrow label */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="flex items-center gap-3 mb-[clamp(0.75rem,2vh,1.5rem)]"
            >
              <div className="h-px w-6 bg-brand-primary shrink-0" />
              <span className="text-brand-primary font-black text-[clamp(0.5rem,2vw,0.7rem)] tracking-[0.4em] uppercase">
                The Architecture of Excellence
              </span>
            </motion.div>

            {/* Main heading — floor raised slightly so it never overflows 320px */}
            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="text-[clamp(2.5rem,9vw,7rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[0.88]"
            >
              Building
              <br />
              <span className="text-brand-sand/20">Scalable</span>
              <br />
              Systems.
            </motion.h1>

            {/* Subtitle — mobile only, sits below heading */}
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="lg:hidden mt-[clamp(0.75rem,2vh,1.25rem)] text-brand-sand/50 text-[clamp(0.875rem,3vw,1rem)] font-medium leading-relaxed"
            >
              A forward-thinking SaaS startup dedicated to transforming ideas into reliable, future-ready digital solutions.
            </motion.p>
          </div>

          {/* Desktop-only right subtitle */}
          <motion.p
            initial={{ opacity: 0, x: 16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="hidden lg:block text-brand-sand/40 text-[clamp(1rem,2vw,1.2rem)] max-w-[320px] font-medium leading-relaxed border-l border-brand-sand/10 pl-8 mb-2"
          >
            A forward-thinking SaaS startup dedicated to transforming ideas into reliable, future-ready digital solutions.
          </motion.p>
        </div>

        {/* ── STATS BAR ──────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-px bg-brand-sand/5 rounded-[1.25rem] md:rounded-[1.5rem] overflow-hidden border border-brand-sand/5 mb-[clamp(2rem,5vh,5rem)]"
        >
          {stats.map((s, i) => (
            <div
              key={i}
              className="bg-brand-graphite px-[clamp(0.875rem,3vw,1.5rem)] py-[clamp(0.875rem,3vh,1.75rem)] flex flex-col gap-1 group hover:bg-brand-primary/10 transition-colors duration-500"
            >
              <span className="text-[clamp(1.5rem,6vw,2.75rem)] font-black text-brand-ivory tracking-tighter leading-none group-hover:text-brand-primary transition-colors duration-500">
                {s.value}
              </span>
              <span className="text-[clamp(0.5rem,1.8vw,0.7rem)] font-black uppercase tracking-[0.2em] text-brand-sand/40 leading-tight">
                {s.label}
              </span>
            </div>
          ))}
        </motion.div>

        {/* ── MAIN CONTENT + VISUAL FEED ─────────────────────────── */}
        <div className="flex flex-col lg:flex-row items-stretch gap-[clamp(1rem,3vw,2rem)] lg:gap-8 mb-[clamp(2rem,5vh,5rem)]">

          {/* Content card */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="w-full lg:w-[58%] bg-brand-graphite rounded-[1.5rem] lg:rounded-[3rem] p-[clamp(1.25rem,5vw,3.5rem)] border border-brand-sand/5 shadow-2xl relative overflow-hidden flex flex-col"
          >
            {/* Corner glow */}
            <div className="absolute top-0 right-0 w-48 h-48 bg-brand-primary/5 rounded-full blur-[80px] pointer-events-none" />

            {/* Mobile image strip */}
            <div className="lg:hidden mb-[clamp(1rem,3vh,1.5rem)]">
              <VisualFeed isMobile />
            </div>

            {/* Body copy */}
            <p className="text-brand-sand/70 text-[clamp(0.875rem,2.5vw,1.2rem)] leading-relaxed font-medium mb-[clamp(1.25rem,4vh,2.5rem)]">
              We are a forward-thinking SaaS startup dedicated to building scalable, high-performance systems tailored to our customers' unique needs. Our mission is simple: transform ideas into reliable, future-ready digital solutions that grow alongside your business.
            </p>

            {/* Pillars grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-[clamp(0.875rem,2.5vh,1.5rem)] pt-[clamp(1rem,3vh,2rem)] border-t border-brand-sand/8 mt-auto">
              {pillars.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.07 }}
                  className="group"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-brand-primary shrink-0" />
                    <span className="text-brand-ivory font-black uppercase text-[clamp(0.55rem,1.5vw,0.65rem)] tracking-[0.2em]">
                      {item.t}
                    </span>
                  </div>
                  <p className="text-brand-sand/40 text-[clamp(0.8rem,2vw,0.875rem)] leading-relaxed font-medium group-hover:text-brand-sand/60 transition-colors duration-300 pl-[1.125rem]">
                    {item.d}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* CTA row */}
            <div className="mt-[clamp(1.25rem,4vh,2.5rem)] pt-[clamp(1rem,3vh,2rem)] border-t border-brand-sand/8 flex flex-wrap items-center gap-3">
              <Link
                to="/contact"
                className="group relative flex items-center gap-2 px-[clamp(1rem,4vw,1.75rem)] py-[clamp(0.625rem,2vh,0.875rem)] bg-brand-primary text-white font-black rounded-full overflow-hidden transition-transform hover:scale-105 active:scale-95 text-[clamp(0.6rem,1.8vw,0.7rem)] tracking-[0.2em] uppercase"
              >
                <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                <span className="relative z-10">Start a Project</span>
                <ArrowUpRight size={12} className="relative z-10 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
              </Link>
              <Link
                to="/services"
                className="text-brand-sand/40 hover:text-brand-primary transition-colors duration-300 font-black text-[clamp(0.6rem,1.8vw,0.7rem)] tracking-[0.2em] uppercase flex items-center gap-1.5"
              >
                Our Services
                <ArrowUpRight size={11} />
              </Link>
            </div>
          </motion.div>

          {/* Visual feed — desktop only, unchanged */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="hidden lg:flex lg:w-[42%] h-[75vh] sticky top-[7rem] bg-brand-graphite rounded-[3rem] border border-brand-sand/5 overflow-hidden shadow-2xl flex-col"
          >
            <div className="absolute inset-0 z-20 pointer-events-none">
              <div className="absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-brand-graphite via-brand-graphite/60 to-transparent" />
              <div className="absolute bottom-0 inset-x-0 h-28 bg-gradient-to-t from-brand-graphite via-brand-graphite/60 to-transparent" />
            </div>
            <div className="px-8 pt-12 pb-4 h-full overflow-hidden">
              <VisualFeed />
            </div>
            <div className="absolute bottom-6 right-6 z-30 px-4 py-2 bg-brand-ink/90 backdrop-blur-2xl border border-brand-sand/10 rounded-full shadow-lg">
              <span className="text-brand-ivory text-[0.6rem] font-black tracking-widest uppercase flex items-center gap-2.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-primary opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-primary" />
                </span>
                Active Lab Feed
              </span>
            </div>
          </motion.div>
        </div>

        {/* ── CORE VALUES ────────────────────────────────────────── */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex items-center gap-3 mb-[clamp(1rem,3vh,1.5rem)]"
          >
            <div className="h-px w-6 bg-brand-primary shrink-0" />
            <span className="text-brand-primary font-black text-[clamp(0.55rem,1.8vw,0.65rem)] tracking-[0.4em] uppercase">
              Core Values
            </span>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-[clamp(0.625rem,2vw,1rem)] md:gap-4">
            {values.map((v, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.5 }}
                className="group relative flex flex-col gap-3 p-[clamp(1rem,3vw,2rem)] lg:p-8 bg-brand-graphite border border-brand-sand/5 rounded-[1.25rem] lg:rounded-[2rem] hover:border-brand-primary/30 transition-all duration-500 overflow-hidden"
              >
                <div className="absolute inset-0 bg-brand-primary/0 group-hover:bg-brand-primary/[0.03] transition-colors duration-500 rounded-[inherit]" />

                <div className="w-9 h-9 md:w-10 md:h-10 rounded-xl flex items-center justify-center bg-brand-ink border border-brand-sand/10 group-hover:border-brand-primary/40 group-hover:bg-brand-primary/10 transition-all duration-500 shrink-0">
                  <v.icon className="w-4 h-4 text-brand-sand/40 group-hover:text-brand-primary transition-colors duration-500" />
                </div>

                <div>
                  <h3 className="text-[clamp(0.8rem,2.5vw,1rem)] font-black text-brand-ivory uppercase tracking-tight mb-1.5 group-hover:text-brand-primary transition-colors duration-500 leading-none">
                    {v.title}
                  </h3>
                  <p className="text-brand-sand/50 text-[clamp(0.78rem,2vw,0.875rem)] leading-relaxed font-medium">
                    {v.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </main>
  );
}
