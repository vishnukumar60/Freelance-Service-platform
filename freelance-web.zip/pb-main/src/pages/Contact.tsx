﻿import { useState, useEffect, useRef, memo } from 'react';
import { useLocation } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, MapPin, Mail, Phone, CheckCircle2, ChevronDown, ArrowUpRight, Hash } from 'lucide-react';
import emailjs from '@emailjs/browser';
import { PageBackground } from '@/components/ui/Layout';

const CONTACT_INFO = [
  { icon: Mail,  label: 'Email',    value: 'phoenixbrothersofficial@gmail.com', link: 'mailto:phoenixbrothersofficial@gmail.com' },
  { icon: Phone, label: 'Phone',    value: ['+91 79047 15141', '+91 93615 64248'], link: 'tel:+917904715141' },
  { icon: MapPin,label: 'Location', value: ['Kongunadu College of Technology', 'Tholurpatti, Tamil Nadu 621215'], link: 'https://www.google.com/maps/search/?api=1&query=Kongunadu+College+of+Engineering+and+Technology,+Tholurpatti,+Tamil+Nadu+621215' },
];

const INTENT_OPTIONS = [
  'SaaS Engineering', 'AI & Machine Learning', 'Custom Enterprise ERP',
  'Cloud Architecture', 'Brand Identity & UX', 'Web3 / Blockchain', 'Ongoing Maintenance',
];

/* ── Floating Label Input ──────────────────────────────────────────── */
const FloatInput = memo(function FloatInput({ label, name, type = 'text', required = false, placeholder = '' }:
  { label: string; name?: string; type?: string; required?: boolean; placeholder?: string }) {
  const [focused, setFocused] = useState(false);
  const [filled,  setFilled]  = useState(false);
  const up = focused || filled;
  return (
    <div className="relative">
      <label className={`absolute left-4 pointer-events-none font-bold z-10 transition-all duration-300 ${
        up ? 'top-2 text-[9px] tracking-[0.2em] text-brand-primary uppercase'
           : 'top-1/2 -translate-y-1/2 text-xs text-brand-sand/30'
      }`}>{label}</label>
      <input
        type={type} required={required} placeholder={focused ? placeholder : ''}
        name={name}
        onFocus={() => setFocused(true)}
        onBlur={e => { setFocused(false); setFilled(e.target.value.length > 0); }}
        className="w-full bg-brand-ink border border-brand-sand/10 rounded-xl px-4 pt-6 pb-2.5 text-brand-ivory text-sm outline-none transition-all duration-300 focus:border-brand-primary/60 placeholder:text-brand-sand/20"
      />
    </div>
  );
});

/* ── Floating Label Textarea ───────────────────────────────────────── */
const FloatTextarea = memo(function FloatTextarea({ label, name, rows = 3 }: { label: string; name?: string; rows?: number }) {
  const [focused, setFocused] = useState(false);
  const [filled,  setFilled]  = useState(false);
  const up = focused || filled;
  return (
    <div className="relative">
      <label className={`absolute left-4 pointer-events-none font-bold z-10 transition-all duration-300 ${
        up ? 'top-2 text-[9px] tracking-[0.2em] text-brand-primary uppercase'
           : 'top-3.5 text-xs text-brand-sand/30'
      }`}>{label}</label>
      <textarea
        rows={rows}
        name={name}
        onFocus={() => setFocused(true)}
        onBlur={e => { setFocused(false); setFilled(e.target.value.length > 0); }}
        className="w-full bg-brand-ink border border-brand-sand/10 rounded-xl px-4 pt-7 pb-3 text-brand-ivory text-sm outline-none transition-all duration-300 focus:border-brand-primary/60 resize-none"
      />
    </div>
  );
});

/* ── Intent Dropdown (portal-rendered so it never gets clipped) ────── */
function IntentDropdown({
  selected, onSelect,
}: { selected: string; onSelect: (v: string) => void }) {
  const triggerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [rect, setRect] = useState<DOMRect | null>(null);

  const handleOpen = () => {
    if (triggerRef.current) setRect(triggerRef.current.getBoundingClientRect());
    setOpen(!open);
  };

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent | TouchEvent) => {
      // Check if click is inside trigger OR inside the portal dropdown
      if (
        (triggerRef.current && triggerRef.current.contains(e.target as Node)) ||
        (dropdownRef.current && dropdownRef.current.contains(e.target as Node))
      ) {
        return;
      }
      setOpen(false);
    };
    document.addEventListener('mousedown', close);
    document.addEventListener('touchstart', close);
    return () => {
      document.removeEventListener('mousedown', close);
      document.removeEventListener('touchstart', close);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    let rafId = 0;
    const update = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        if (triggerRef.current) setRect(triggerRef.current.getBoundingClientRect());
      });
    };
    window.addEventListener('scroll', update, { passive: true, capture: true });
    window.addEventListener('resize', update, { passive: true });
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('scroll', update, true);
      window.removeEventListener('resize', update);
    };
  }, [open]);

  return (
    <div ref={triggerRef} className="relative">
      <div
        onClick={handleOpen}
        className={`relative w-full bg-brand-ink border rounded-xl px-4 pt-6 pb-2.5 cursor-pointer transition-all duration-300 select-none ${
          open ? 'border-brand-primary/60' : 'border-brand-sand/10 hover:border-brand-sand/20'
        }`}
      >
        <span className="absolute left-4 top-2 text-[9px] tracking-[0.2em] text-brand-primary uppercase font-bold">
          Project Intent
        </span>
        <div className="flex items-center justify-between">
          <span className="text-brand-ivory text-sm font-medium truncate pr-2">{selected}</span>
          <ChevronDown
            size={14}
            className={`text-brand-primary flex-shrink-0 transition-transform duration-300 ${open ? 'rotate-180' : ''}`}
          />
        </div>
      </div>

      {open && rect && createPortal(
        <AnimatePresence>
          <motion.div
            key="dropdown"
            ref={dropdownRef}
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            style={{
              position: 'fixed',
              top: rect.bottom + 6,
              left: rect.left,
              width: rect.width,
              zIndex: 9999,
              backgroundColor: '#191222',
              borderRadius: '1rem',
              border: '1px solid rgba(255,106,0,0.4)',
              boxShadow: '0 20px 60px rgba(0,0,0,0.85)',
            }}
          >
            <div
              style={{
                maxHeight: '196px',
                overflowY: 'auto',
                WebkitOverflowScrolling: 'touch',
                overscrollBehavior: 'contain',
              }}
            >
              {INTENT_OPTIONS.map(opt => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => { onSelect(opt); setOpen(false); }}
                  style={{
                    display: 'block',
                    width: '100%',
                    textAlign: 'left',
                    padding: '12px 20px',
                    fontSize: '14px',
                    fontWeight: 500,
                    background: selected === opt ? '#FF6A00' : 'transparent',
                    color: selected === opt ? '#fff' : 'rgba(255,255,255,0.55)',
                    transition: 'background 0.15s, color 0.15s',
                    border: 'none',
                    cursor: 'pointer',
                  }}
                  onMouseEnter={e => { if (selected !== opt)(e.currentTarget.style.background = 'rgba(255,255,255,0.06)'); (e.currentTarget.style.color = '#fff'); }}
                  onMouseLeave={e => { if (selected !== opt)(e.currentTarget.style.background = 'transparent'); (e.currentTarget.style.color = 'rgba(255,255,255,0.55)'); }}
                >
                  {opt}
                </button>
              ))}
            </div>
          </motion.div>
        </AnimatePresence>,
        document.body
      )}
    </div>
  );
}

/* ── Main ─────────────────────────────────────────────────────────── */
export default function Contact() {
  const formRef = useRef<HTMLFormElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted,  setIsSubmitted]  = useState(false);
  const [submitError,  setSubmitError]  = useState<string | null>(null);
  const [selectedIntent, setSelectedIntent] = useState(INTENT_OPTIONS[0]);
  const location = useLocation();
  const SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID ?? 'service_hm0kile';
  const ADMIN_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_ADMIN_TEMPLATE_ID ?? 'template_277sryk';
  const AUTO_REPLY_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_AUTO_REPLY_TEMPLATE_ID ?? 'template_8ufcwz7';
  const PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY ?? '0mcBtcGGy2NrpPkAd';

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!formRef.current) return;

    // Basic client-side validation
    const formData = new FormData(formRef.current);
    const name  = String(formData.get('user_name') ?? '').trim();
    const email = String(formData.get('user_email') ?? '').trim();
    if (!name || !email) {
      setSubmitError('Please fill in your name and email address.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setSubmitError('Please enter a valid email address.');
      return;
    }

    setSubmitError(null);
    setIsSubmitting(true);
    try {
      const templateParams = {
        user_name: name,
        user_email: email,
        phone: String(formData.get('user_phone') ?? ''),
        country: String(formData.get('user_country') ?? ''),
        organization: String(formData.get('user_org') ?? ''),
        project_intent: String(formData.get('project_intent') ?? selectedIntent),
        message: String(formData.get('message') ?? ''),
        current_date: new Date().toLocaleString('en-IN', {
          day: '2-digit', month: 'long', year: 'numeric',
          hour: '2-digit', minute: '2-digit',
        }),
        reply_to: email,
      };

      await Promise.all([
        emailjs.send(SERVICE_ID, ADMIN_TEMPLATE_ID, templateParams, PUBLIC_KEY),
        emailjs.send(SERVICE_ID, AUTO_REPLY_TEMPLATE_ID, templateParams, PUBLIC_KEY),
      ]);
      setIsSubmitted(true);
    } catch (error) {
      console.error('EmailJS Error:', error);
      setSubmitError('Failed to send your message. Please try again or email us directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
    if (location.hash === '#brief' || window.location.hash === '#brief') {
      const timer = setTimeout(() => {
        formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [location]);

  return (
    <section className="bg-brand-ink py-[clamp(6rem,15vh,10rem)] pb-[clamp(4rem,10vh,6rem)] overflow-x-hidden relative min-h-screen">

      <PageBackground />

      <div className="w-full max-w-[1400px] mx-auto px-[clamp(1rem,4vw,2rem)] relative z-10">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10 lg:mb-20">
          <div className="max-w-[700px]">
            <motion.div
              initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }}
              className="flex items-center gap-4 mb-8"
            >
              <div className="h-px w-8 bg-brand-primary" />
              <span className="text-brand-primary font-black text-[clamp(0.6rem,1.5vw,0.75rem)] tracking-[0.5em] uppercase">
                Secure Submission
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-[clamp(3.5rem,9vw,7rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[0.85]"
            >
              Let's build <br className="hidden sm:block" /><span className="text-brand-sand/20">something great.</span>
            </motion.h1>
          </div>

          <motion.p
            initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }}
            className="text-brand-sand/40 text-lg md:text-xl lg:max-w-[320px] font-medium leading-relaxed border-l border-brand-sand/10 pl-8 mb-4 hidden lg:block"
          >
            We combine high-level engineering with artistic design to build SaaS that resonates.
          </motion.p>

          <p className="lg:hidden text-brand-sand/40 text-sm leading-relaxed -mt-4 font-medium italic">
            Engineering power meets creative vision.
          </p>
        </div>

        <div className="flex flex-col lg:grid lg:grid-cols-12 gap-8 lg:gap-12">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.8 }}
            className="order-1 lg:order-2 lg:col-span-8 scroll-mt-32"
            id="brief"
          >
            <div className="relative bg-brand-graphite rounded-[2.5rem] lg:rounded-[4rem] p-8 md:p-12 lg:p-16 border border-brand-sand/5 shadow-2xl overflow-hidden group">
              <div className="absolute inset-0 bg-white/[0.01]" />
              <div className="absolute top-0 right-0 w-64 h-64 bg-brand-primary/5 rounded-full blur-[100px] pointer-events-none group-hover:bg-brand-primary/10 transition-all duration-700" />

              <AnimatePresence mode="wait">
                {!isSubmitted ? (
                  <motion.form
                    key="form" ref={formRef} onSubmit={handleSubmit}
                    exit={{ opacity: 0, scale: 0.97 }}
                    className="space-y-6 md:space-y-8 relative z-10"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-brand-primary font-black text-[clamp(0.5rem,1.5vw,0.5625rem)] tracking-[0.4em] uppercase mb-2 block">
                          Project Brief
                        </span>
                        <h2 className="text-[1.75rem] sm:text-[clamp(1.75rem,3vw,2.5rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[1.1]">
                          Tell Us <br className="sm:hidden" /><span className="text-brand-sand/20">Your Vision.</span>
                        </h2>
                      </div>

                    </div>

                    <div className="h-px w-full bg-brand-sand/5" />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FloatInput label="Your Name" name="user_name" required placeholder="John Doe" />
                      <FloatInput label="Email Address" name="user_email" type="email" required placeholder="john@company.com" />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FloatInput label="Phone Number" name="user_phone" type="tel" placeholder="+91 00000 00000" />
                      <FloatInput label="Country / Region" name="user_country" placeholder="India" />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <FloatInput label="Organization" name="user_org" placeholder="Company Ltd." />
                      <div className="relative">
                        <input type="hidden" name="project_intent" value={selectedIntent} />
                        <IntentDropdown selected={selectedIntent} onSelect={setSelectedIntent} />
                      </div>
                    </div>

                    <FloatTextarea label="Your vision or challenge (optional)" name="message" rows={4} />

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-6 pt-6 border-t border-brand-sand/5">
                      <p className="text-brand-sand/25 text-[10px] leading-relaxed max-w-[280px]">
                        By submitting, you agree to our processing of your details to respond to this specific inquiry.
                      </p>
                      <div className="flex flex-col items-end gap-3 sm:shrink-0">
                        {submitError && (
                          <p className="text-red-400 text-xs font-medium text-right max-w-[280px]">{submitError}</p>
                        )}
                        <button
                          type="submit" disabled={isSubmitting}
                          className="group relative flex items-center justify-center gap-4 px-10 py-5 bg-brand-primary text-brand-ivory font-black rounded-full overflow-hidden transition-all duration-300 hover:scale-105 active:scale-95 disabled:opacity-60 w-full sm:w-auto"
                        >
                          <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                          <span className="relative z-10 tracking-[0.2em] text-[10px] uppercase">
                            {isSubmitting ? 'Sending…' : 'Initialize Project'}
                          </span>
                          {!isSubmitting && <Send size={16} className="relative z-10 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform duration-300" />}
                        </button>
                      </div>
                    </div>
                  </motion.form>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.93 }} animate={{ opacity: 1, scale: 1 }}
                    transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                    className="py-16 md:py-24 flex flex-col items-center text-center gap-8 relative z-10"
                  >
                    <div className="relative">
                      <div className="w-24 h-24 rounded-full bg-brand-primary/10 border border-brand-primary/30 flex items-center justify-center">
                        <CheckCircle2 size={44} className="text-brand-primary" />
                      </div>
                      <motion.div
                        className="absolute inset-0 rounded-full border border-brand-primary/20"
                        animate={{ scale: [1, 1.8], opacity: [0.4, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      />
                    </div>
                    <div>
                      <h2 className="text-[clamp(1.75rem,6vw,3rem)] font-black tracking-tighter uppercase text-brand-ivory mb-3">Transmission Confirmed</h2>
                      <p className="text-brand-sand/40 font-medium text-lg">An engineer will review your brief within 24 hours.</p>
                    </div>
                    <button
                      onClick={() => setIsSubmitted(false)}
                      className="group relative text-brand-ivory font-black text-[10px] tracking-[0.3em] uppercase border border-brand-sand/10 px-10 py-5 rounded-full overflow-hidden hover:border-brand-primary transition-all duration-300"
                    >
                      <div className="absolute inset-0 bg-brand-primary translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
                      <span className="relative z-10 group-hover:text-brand-ivory transition-colors duration-300">Submit Another Brief →</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>

          <div className="order-2 lg:order-1 lg:col-span-4 flex flex-col gap-8 h-full">
            <div className="flex flex-col gap-6 lg:gap-8 grow">
              {CONTACT_INFO.map((item, i) => (
                <motion.a
                  key={i} href={item.link}
                  target={item.icon === MapPin ? '_blank' : undefined} rel="noopener noreferrer"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: i * 0.1 }}
                  className="group relative rounded-[1rem] lg:rounded-[2.5rem] overflow-hidden bg-brand-graphite border border-brand-sand/5 p-3 lg:p-8 flex items-center gap-3.5 lg:gap-6 cursor-pointer transition-all duration-500 hover:border-brand-primary/30 hover:bg-brand-ink/40 w-full shadow-2xl"
                >
                  <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-0 group-hover:opacity-10 transition-opacity duration-700">
                    <div className="w-full h-[1px] bg-brand-primary absolute animate-[scan_3s_linear_infinite]" />
                  </div>
                  <div className="absolute inset-0 bg-brand-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />

                  <div className="relative z-10 w-8 h-8 lg:w-11 lg:h-11 rounded-lg lg:rounded-xl bg-brand-ink border border-brand-sand/10 flex items-center justify-center text-brand-sand/40 group-hover:text-brand-primary group-hover:border-brand-primary/50 transition-all duration-500 flex-shrink-0">
                    <item.icon size={16} strokeWidth={1.5} />
                  </div>

                  <div className="relative z-10 flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="h-[1px] w-2.5 bg-brand-primary group-hover:w-8 transition-all duration-500" />
                      <span className="text-[0.45rem] lg:text-[0.55rem] font-black tracking-[0.4em] uppercase text-brand-sand/40 group-hover:text-brand-primary transition-colors">
                        {item.label}
                      </span>
                    </div>
                    <div className="flex flex-col group-hover:translate-x-2 transition-transform duration-500">
                      {Array.isArray(item.value) ? (
                        item.value.map((v, idx) => (
                          <p key={idx} className="text-brand-ivory font-bold text-sm md:text-base lg:text-lg truncate leading-tight mb-1 last:mb-0">
                            {v}
                          </p>
                        ))
                      ) : (
                        <p className="text-brand-ivory font-bold text-sm md:text-base lg:text-lg truncate">
                          {item.value}
                        </p>
                      )}
                    </div>
                  </div>

                  <ArrowUpRight size={14} className="relative z-10 text-brand-sand/20 group-hover:text-brand-primary group-hover:translate-x-1 group-hover:-translate-y-1 transition-all duration-300 flex-shrink-0" />
                </motion.a>
              ))}
            </div>

            {/* Stat card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="relative rounded-[1.25rem] lg:rounded-[2.5rem] bg-brand-graphite border border-brand-sand/5 p-4 lg:p-6 overflow-hidden shadow-2xl mt-auto"
            >
              <div className="absolute top-0 right-0 w-48 h-48 bg-brand-primary/5 rounded-full blur-[60px]" />
              <div className="flex items-center gap-3 mb-2 relative z-10">
                <Hash size={14} className="text-brand-primary" />
                <span className="text-[0.45rem] lg:text-[0.55rem] font-black tracking-[0.4em] uppercase text-brand-sand/40">Response Protocol</span>
              </div>
              <div className="flex items-end gap-2.5 mb-1.5 relative z-10">
                <span className="text-4xl md:text-5xl font-black text-brand-ivory tracking-tighter leading-none">&lt;24</span>
                <span className="text-brand-primary text-sm font-black uppercase tracking-widest mb-1">Hrs</span>
              </div>
              <p className="text-brand-sand/40 text-[0.75rem] lg:text-sm leading-relaxed font-medium relative z-10">Guaranteed engineer response within one business cycle.</p>
            </motion.div>
          </div>
        </div>
      </div>
</section>
  );
}