import { memo, useState, useCallback } from 'react';
import { motion, AnimatePresence, LayoutGroup } from 'framer-motion';
import { PageBackground } from '@/components/ui/Layout';
import { X } from 'lucide-react';

interface TeamMember {
  name: string;
  role: string;
  image: string;
  bio: string;
  featured?: boolean;
}

const team: TeamMember[] = [
  {
    name: 'Mukesh',
    role: 'CEO',
    image: '/mukesh.jpeg',
    bio: 'Driving strategic vision and innovation, leading the company toward scalable growth and long-term impact through technology and leadership.',
    featured: true,
  },
  {
    name: 'Yasvand',
    role: 'Intern Student',
    image: '/yasvand.jpeg',
    bio: 'Leading technical architecture and engineering excellence, building robust, scalable systems with a strong focus on performance and innovation.',
    featured: true,
  },
 {
    name: 'Vishnu Kumar',
    role: 'Front-End Developer & UI Designer',
    image: '/vishnu.png',
    bio: 'Crafting modern, responsive interfaces with a focus on usability, performance, and seamless user experience across all devices.',
  },
  {
    name: 'Akhil',
    role: 'Back-end Developer',
    image: '/akhil.png',
    bio: 'Developing secure, scalable backend systems with efficient APIs, database architecture, and reliable server-side logic.',
  },
  {
    name: 'Praveen',
    role: 'Digital Marketing Specialist',
    image: '/praveen.jpeg',
    bio: 'Driving brand growth through data-driven marketing strategies, SEO optimization, and high-conversion digital campaigns.',
  },
];

// ─── Team Card ────────────────────────────────────────────────────────────────
// Mobile: tapping expands the card in-place with a detail panel.
// Desktop: hover dropup panel (unchanged).

const TeamCard = memo(({ member, delay, expandedId, onExpand }: {
  member: TeamMember;
  delay: number;
  expandedId: string | null;
  onExpand: (name: string | null) => void;
}) => {
  const isTop = member.name === 'Mukesh' || member.name === 'Yasvand';
  const isExpanded = expandedId === member.name;

  const handleTap = useCallback(() => {
    // Only expand on mobile (md breakpoint = 768px)
    if (window.innerWidth >= 768) return;
    onExpand(isExpanded ? null : member.name);
  }, [isExpanded, member.name, onExpand]);

  const layoutTransition = { duration: 0.42, ease: [0.23, 1, 0.32, 1] as any };

  return (
    <motion.div
      layout
      layoutId={`team-wrap-${member.name}`}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{
        layout: layoutTransition,
        opacity: { duration: 0.55, delay },
        y: { duration: 0.55, delay },
      }}
      // Expanded card spans both columns on mobile
      className={isExpanded ? 'col-span-2' : 'col-span-1'}
    >
      <motion.div
        layout
        layoutId={`team-card-${member.name}`}
        transition={{ layout: layoutTransition }}
        onClick={handleTap}
        tabIndex={0}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleTap(); }}
        className={[
          'group relative overflow-hidden cursor-pointer outline-none',
          'rounded-[1.25rem] md:rounded-[2rem]',
          isExpanded
            ? 'border border-brand-primary/30 shadow-[0_4px_32px_rgba(255,106,0,0.12)] bg-brand-graphite'
            : 'aspect-[3/4] border border-brand-sand/8 bg-brand-graphite shadow-lg',
        ].join(' ')}
      >
        <AnimatePresence mode="wait" initial={false}>
          {!isExpanded ? (
            /* ── COLLAPSED: photo card (mobile + desktop) ─────── */
            <motion.div
              key="collapsed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="absolute inset-0"
            >
              {/* Photo */}
              <img
                src={member.image}
                alt={member.name}
                className={[
                  'absolute inset-0 w-full h-full object-cover',
                  'transition-all duration-700 ease-out',
                  'grayscale group-hover:grayscale-0 group-focus:grayscale-0',
                  'scale-100 group-hover:scale-105 group-focus:scale-105',
                  isTop ? 'object-top' : 'object-center',
                ].join(' ')}
              />

              {/* Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent pointer-events-none" />

              {/* ── MOBILE: name strip + tap hint ── */}
              <div className="md:hidden absolute bottom-0 left-0 right-0 z-20 px-[clamp(0.625rem,3vw,0.875rem)] pb-[clamp(0.625rem,2.5vw,0.875rem)] pt-8">
                <span className="text-brand-primary font-black text-[clamp(0.45rem,1.8vw,0.55rem)] tracking-[0.2em] uppercase leading-none block mb-1 line-clamp-1">
                  {member.role}
                </span>
                <h4 className="text-white font-black text-[clamp(0.85rem,3.8vw,1.05rem)] tracking-tight leading-tight line-clamp-1">
                  {member.name}
                </h4>
                {/* Tap indicator */}
                <div className="mt-1.5 flex items-center gap-1 opacity-50">
                  <div className="w-3 h-[1.5px] bg-brand-primary rounded-full" />
                  <span className="text-brand-primary/80 text-[0.42rem] font-black tracking-[0.2em] uppercase">Tap</span>
                </div>
              </div>

              {/* ── DESKTOP: dropup panel ── */}
              <div
                className="hidden md:flex absolute bottom-0 left-0 right-0 h-[27%] z-20
                           bg-brand-surface backdrop-blur-md
                           translate-y-full group-hover:translate-y-0 group-focus:translate-y-0
                           transition-transform duration-500 ease-[cubic-bezier(0.23,1,0.32,1)]
                           flex-col justify-between
                           px-4 lg:px-[1.1rem] pt-3 lg:pt-3.5 pb-4 lg:pb-[1.1rem]"
              >
                <div className="absolute top-0 left-0 right-0 h-[3px] bg-brand-primary" />
                <div className="flex flex-col gap-0.5">
                  <span className="text-brand-primary font-black text-[0.55rem] lg:text-[0.54rem] tracking-[0.25em] uppercase leading-none line-clamp-1">
                    {member.role}
                  </span>
                  <h4 className="text-brand-text font-black text-[clamp(0.9rem,2vw,1rem)] lg:text-[clamp(0.82rem,1.8vw,0.92rem)] tracking-tight leading-tight line-clamp-1">
                    {member.name}
                  </h4>
                </div>
                <div className="h-px bg-brand-text/10 shrink-0" />
                <p className="text-brand-text/65 text-[clamp(0.7rem,1.3vw,0.8rem)] lg:text-[clamp(0.64rem,1.15vw,0.76rem)] leading-relaxed line-clamp-3 font-medium">
                  {member.bio}
                </p>
              </div>

              {/* Hover/focus ring */}
              <div className="absolute inset-0 rounded-[1.25rem] md:rounded-[2rem] ring-1 ring-inset ring-brand-primary/0 group-hover:ring-brand-primary/30 group-focus:ring-brand-primary/30 transition-all duration-500 pointer-events-none" />
            </motion.div>

          ) : (
            /* ── EXPANDED: detail panel (mobile only) ─────────── */
            <motion.div
              key="expanded"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.22 }}
              className="flex flex-row"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Left: photo strip */}
              <div className="relative w-[38%] shrink-0 overflow-hidden" style={{ minHeight: '160px' }}>
                <img
                  src={member.image}
                  alt={member.name}
                  className={[
                    'w-full h-full object-cover',
                    isTop ? 'object-top' : 'object-center',
                  ].join(' ')}
                  style={{ minHeight: '160px' }}
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-brand-graphite/60" />
              </div>

              {/* Right: detail */}
              <div className="relative flex flex-col gap-2.5 p-4 flex-1 bg-brand-graphite">
                {/* Orange accent bar */}
                <div className="absolute top-0 left-0 right-0 h-[3px] bg-brand-primary" />

                {/* Close */}
                <button
                  onClick={(e) => { e.stopPropagation(); onExpand(null); }}
                  aria-label="Collapse"
                  className="absolute top-3 right-3 w-7 h-7 rounded-full bg-brand-sand/8 border border-brand-sand/10 flex items-center justify-center text-brand-sand/40 hover:text-brand-primary hover:border-brand-primary active:scale-95 transition-all duration-200 touch-manipulation"
                >
                  <X size={12} />
                </button>

                {/* Role + Name */}
                <div className="pr-8 mt-1">
                  <span className="text-brand-primary font-black text-[0.48rem] tracking-[0.3em] uppercase block mb-1">
                    {member.role}
                  </span>
                  <h4 className="text-brand-text font-black text-[clamp(0.9rem,3.5vw,1.1rem)] tracking-tight leading-tight">
                    {member.name}
                  </h4>
                </div>

                <div className="h-px bg-brand-text/10 shrink-0" />

                {/* Bio */}
                <p className="text-brand-text/70 text-[clamp(0.7rem,2.5vw,0.8rem)] leading-relaxed font-medium">
                  {member.bio}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
});

TeamCard.displayName = 'TeamCard';

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function Team() {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const handleExpand = useCallback((name: string | null) => {
    setExpandedId(name);
  }, []);

  return (
    <section className="bg-brand-ink py-[clamp(5rem,15vh,8rem)] overflow-hidden relative min-h-screen">

      <PageBackground />

      <div className="max-w-[1400px] lg:max-w-[1260px] mx-auto px-[clamp(1rem,4vw,2rem)] relative z-10 w-full">

        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-[clamp(2.5rem,7vh,6rem)]">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-3 mb-[clamp(0.75rem,2.5vh,1.5rem)]"
            >
              <div className="h-px w-8 bg-brand-primary shrink-0" />
              <span className="text-brand-primary font-black text-[clamp(0.5rem,1.5vw,0.625rem)] tracking-[0.5em] uppercase">
                The Specialized Unit
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="text-[clamp(2.75rem,9vw,7rem)] font-black text-brand-ivory tracking-tighter uppercase leading-[0.85]"
            >
              Elite <br />
              <span className="text-brand-sand/20">Operations.</span>
            </motion.h1>

            {/* Mobile subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="lg:hidden mt-3 text-brand-sand/40 text-[clamp(0.875rem,3vw,1rem)] font-medium leading-relaxed max-w-[38ch]"
            >
              A lean collective of six architects delivering the strategic depth of a global organisation.
            </motion.p>
          </div>

          <motion.p
            initial={{ opacity: 0, x: 16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="hidden lg:block text-brand-sand/40 text-[clamp(1rem,2vw,1.2rem)] max-w-[320px] font-medium leading-relaxed border-l border-brand-sand/10 pl-8 mb-2"
          >
            Precision-engineered for scale. A lean collective of six architects delivering the strategic depth of a global organisation.
          </motion.p>
        </div>

        {/* Grid — 2 cols mobile, 3 cols md+ */}
        <LayoutGroup>
          <motion.div
            layout
            className="grid grid-cols-2 md:grid-cols-3 gap-[clamp(0.625rem,2.5vw,1.25rem)]"
            transition={{ layout: { duration: 0.42, ease: [0.23, 1, 0.32, 1] } }}
          >
            {team.map((member, i) => (
              <TeamCard
                key={member.name}
                member={member}
                delay={i * 0.07}
                expandedId={expandedId}
                onExpand={handleExpand}
              />
            ))}
          </motion.div>
        </LayoutGroup>

      </div>

    </section>
  );
}
