# Phoenix Typography System

A comprehensive, consistent, and responsive typography system for the entire Phoenix Brothers website. This guide ensures visual harmony and professional consistency across all pages and components.

---

## 1. Font Family

### Primary Font: Inter
- **Imported**: Google Fonts (optimized with selected weights only)
- **Weights**: 400, 500, 600, 700, 800, 900
- **Usage**: All text across the website
- **Fallback**: `ui-sans-serif, system-ui, sans-serif`

```css
font-family: "Inter", ui-sans-serif, system-ui, sans-serif;
```

### Monospace Font (Code/Data)
- **Font**: Fira Code or Courier New
- **Usage**: Code blocks, mono text, meta information
- **Class**: `.font-mono`

---

## 2. Typography Scale System

### Font Sizes (Tailwind Tokens)

| Size | CSS Value | Tailwind Class | Use Case |
|------|-----------|---|----------|
| `text-xs` | 0.75rem (12px) | Caption, labels, meta | Small text |
| `text-sm` | 0.875rem (14px) | Body, secondary text | Small body copy |
| `text-base` | 1rem (16px) | Body, default | Main body text |
| `text-lg` | 1.125rem (18px) | Emphasized text | Lead paragraph |
| `text-xl` | 1.25rem (20px) | - | Medium text |
| `text-2xl` | 1.5rem (24px) | - | - |
| `text-3xl` | 1.875rem (30px) | Heading small | H3 style |
| `text-4xl` | 2.25rem (36px) | - | - |
| `text-5xl` | 3rem (48px) | Display | Large heading |
| `text-6xl` | 3.75rem (60px) | - | - |
| `text-7xl` | 4.5rem (72px) | Display large | Hero title |
| `text-8xl` | 6rem (96px) | Display XL | Banner |

### Responsive Typography

Use Tailwind's responsive prefixes for different screen sizes:

```html
<!-- Mobile: 24px, Tablet: 36px, Desktop: 48px -->
<h1 class="text-2xl md:text-4xl lg:text-6xl">Responsive Heading</h1>

<!-- Using typography utility classes -->
<h1 class="text-display-lg">Hero Title (5xl-7xl-8xl responsive)</h1>
<h2 class="text-display-md">Large Display (4xl-6xl responsive)</h2>
```

---

## 3. Heading Hierarchy

### H1 - Display/Hero Heading
- **Font Size**: clamp(2.5rem, 10vw, 5.5rem) - Responsive
- **Font Weight**: 900 (Black)
- **Line Height**: 0.9 (90%)
- **Letter Spacing**: -1.2px (tighter)
- **Margin Bottom**: 1.5rem
- **Color**: `text-brand-text` (solid color, no gradients)

```html
<h1 class="text-display-lg">WE BUILD WHAT OTHERS IMAGINE</h1>
```

### H2 - Section Heading
- **Font Size**: clamp(2rem, 8vw, 4rem)
- **Font Weight**: 800 (Extra Bold)
- **Line Height**: 1.1 (110%)
- **Letter Spacing**: -0.8px (tight)
- **Margin Bottom**: 1.25rem
- **Color**: `text-brand-text`

```html
<h2 class="text-heading-lg">ENGINEERED FOR EXCELLENCE</h2>
```

### H3 - Subsection Heading
- **Font Size**: clamp(1.5rem, 6vw, 2.5rem)
- **Font Weight**: 700 (Bold)
- **Line Height**: 1.2 (120%)
- **Letter Spacing**: -0.5px
- **Margin Bottom**: 1rem
- **Color**: `text-brand-text`

```html
<h3 class="text-heading-md">Feature Heading</h3>
```

### H4 - Feature Heading
- **Font Size**: clamp(1.25rem, 4vw, 1.75rem)
- **Font Weight**: 700 (Bold)
- **Line Height**: 1.3 (130%)
- **Letter Spacing**: -0.4px
- **Margin Bottom**: 0.875rem

```html
<h4 class="text-heading-sm">Sub Feature</h4>
```

### H5 & H6 - Component Headings
- **Font Size**: clamp proportional
- **Font Weight**: 600 (Semibold)
- **Line Height**: 1.4-1.5
- **Letter Spacing**: -0.3px / -0.2px

---

## 4. Body & Text Scales

### Paragraph (Default)
- **Font Size**: 1rem (16px)
- **Line Height**: 1.65 (165%)
- **Letter Spacing**: -0.2px
- **Font Weight**: 400 (Regular)
- **Margin Bottom**: 1rem (last: 0)

```html
<p>Main body copy with optimal readability.</p>
```

### Large Body Text
- **Font Size**: 1.125rem (18px)
- **Line Height**: 1.75 (175%)
- **Letter Spacing**: -0.2px
- **Font Weight**: 400 (Regular)
- **Class**: `.text-body-lg` or `.text-lg`

```html
<p class="text-body-lg">Emphasized paragraph with larger size.</p>
```

### Small Body Text
- **Font Size**: 0.875rem (14px)
- **Line Height**: 1.5 (150%)
- **Letter Spacing**: -0.1px
- **Font Weight**: 400 (Regular)
- **Class**: `.text-body-sm` or `.text-sm`

```html
<p class="text-body-sm">Secondary information or smaller text.</p>
```

### Extra Small Text (Captions/Labels)
- **Font Size**: 0.75rem (12px)
- **Line Height**: 1.4 (140%)
- **Letter Spacing**: 0em (normal)
- **Font Weight**: 500 (Medium)
- **Class**: `.text-xs`

```html
<p class="text-xs">10px equivalent small text.</p>
```

---

## 5. Typography Utility Classes

### Display Classes (Pre-composed for consistency)

```html
<!-- Hero/Display Text -->
<div class="text-display-lg">Largest display text (5xl-7xl-8xl)</div>
<div class="text-display-md">Large display text (4xl-6xl)</div>

<!-- Heading Classes -->
<div class="text-heading-lg">Large heading (3xl-4xl)</div>
<div class="text-heading-md">Medium heading (2xl-3xl)</div>
<div class="text-heading-sm">Small heading (xl-2xl)</div>

<!-- Body Classes -->
<div class="text-body-lg">Large body (18px)</div>
<div class="text-body-md">Default body (16px)</div>
<div class="text-body-sm">Small body (14px)</div>

<!-- Caption/Label Classes -->
<div class="text-caption-lg">Uppercase label with widest spacing</div>
<div class="text-caption-md">Uppercase label with wider spacing</div>
<div class="text-caption-sm">Uppercase label with wide spacing</div>

<!-- Meta Text -->
<div class="text-meta">Secondary, reduced opacity metadata</div>
```

---

## 6. Font Weights

### Weight Tokens

| Name | Weight | Tailwind Class | Use Case |
|------|--------|---|----------|
| Light | 300 | `.font-light` | Spare/elegant text |
| Regular | 400 | `.font-normal` | Default body text |
| Medium | 500 | `.font-medium` | Emphasis, buttons |
| Semibold | 600 | `.font-semibold` | Strong emphasis, labels |
| Bold | 700 | `.font-bold` | Headings, strong text |
| Extra Bold | 800 | `.font-extrabold` | Major headings |
| Black | 900 | `.font-black` | Display/hero text |

```html
<p class="font-light">Light text</p>
<p class="font-normal">Regular text (default)</p>
<p class="font-semibold">Semibold text</p>
<h1 class="font-black">Black text</h1>
```

---

## 7. Line Heights

### Line Height Tokens

| Name | Value | CSS | Use Case |
|------|-------|-----|----------|
| Ultra Tight | 1.0 | `.leading-ultra-tight` | Headings |
| Tight | 1.2 | `.leading-tight` | Subheadings |
| Snug | 1.35 | `.leading-snug` | Body + headings |
| Normal | 1.5 | `.leading-normal` | Standard body |
| Relaxed | 1.65 | `.leading-relaxed` | Main paragraph |
| Loose | 1.8 | `.leading-loose` | Extended reading |

```html
<h1 class="leading-tight">Tighter line height for headings</h1>
<p class="leading-relaxed">Relaxed line height for body text</p>
```

---

## 8. Letter Spacing

### Tracking Tokens

| Name | Value | Tailwind | Use Case |
|------|-------|----------|----------|
| Ultra Tight | -0.12em | `.tracking-ultra-tight` | Display text |
| Tighter | -0.08em | `.tracking-tighter` | Large headings |
| Tight | -0.04em | `.tracking-tight` | Medium headings |
| Normal | 0em | `.tracking-normal` | Body text |
| Wide | 0.04em | `.tracking-wide` | - |
| Wider | 0.08em | `.tracking-wider` | Labels |
| Widest | 0.16em | `.tracking-widest` | Caps text |

```html
<h1 class="tracking-tighter">Tightened letter spacing</h1>
<p class="tracking-normal">Normal spacing (default)</p>
<span class="tracking-widest uppercase">UPPERCASE LABEL</span>
```

### Caption/Label Pattern

```html
<!-- Use .text-caption-* classes for consistent label styling -->
<label class="text-caption-md">Form Label</label>
<span class="text-caption-lg">BADGE LABEL</span>
```

---

## 9. Color Application

### Brand Colors

| Color | Token | Light Mode | Dark Mode |
|-------|-------|-----------|-----------|
| Primary | `--brand-primary` | #D35400 | #D35400 |
| Text | `--brand-text` | #3C2A21 | #F0F8FF |
| Accent | `--brand-accent` | #3C2A21 | #64b4ff |
| Dark BG | `--brand-dark` | #FAF9F6 | #2a2a2e |
| Surface | `--brand-surface` | #E5D3B3 | #242426 |

### Text Color Classes

```html
<!-- Primary text (automatic theme switching) -->
<h1 class="text-brand-text">Heading</h1>

<!-- Primary brand color -->
<span class="text-brand-primary">Accent text</span>

<!-- Secondary/muted text -->
<p class="text-brand-text/60">Secondary information</p>
<p class="text-brand-text/40">Tertiary information</p>
```

---

## 10. Responsive Typography Patterns

### Mobile-First Approach

```html
<!-- Base (mobile) → Tablet (md:) → Desktop (lg:) -->
<h1 class="text-2xl md:text-4xl lg:text-6xl">Responsive Heading</h1>

<!-- Using utility classes -->
<h1 class="text-display-lg">Automatically responsive</h1>

<!-- Body responsive -->
<p class="text-base md:text-lg">Responsive paragraph</p>
```

### Viewport-Based Sizing (clamp)

Headings use CSS `clamp()` for fluid scaling:

```css
h1 {
  font-size: clamp(2.5rem, 10vw, 5.5rem);
  /* Min: 2.5rem (40px) | Ideal: 10vw of viewport | Max: 5.5rem (88px) */
}
```

---

## 11. Form Elements

### Input/Button Typography

- **Font Size**: 1rem (16px) - Prevents zoom on iOS
- **Font Weight**: 500 (Medium)
- **Line Height**: 1.5 (150%)
- **Letter Spacing**: -0.2px
- **Font Family**: Inherit (from body)

```html
<input type="text" placeholder="Enter text...">
<button>Submit</button>
<textarea>Type message...</textarea>
```

### Label Typography

- **Font Size**: 0.875rem (14px)
- **Font Weight**: 600 (Semibold)
- **Line Height**: 1.5 (150%)
- **Letter Spacing**: -0.1px

```html
<label for="email" class="font-semibold text-sm">Email Address</label>
<input id="email" type="email">
```

---

## 12. Best Practices

### ✅ Do

- Use typography utility classes (`.text-heading-lg`, `.text-caption-md`)
- Apply responsive sizing with Tailwind prefixes (`md:`, `lg:`)
- Use semantic HTML (`<h1>`, `<h2>`, `<p>`, etc.)
- Maintain consistent font weights from the defined scale
- Ensure WCAG contrast compliance (AAA minimum)
- Use responsive measurements (clamp) for fluid typography
- Include proper line-height for readability (1.4 minimum)

### ❌ Don't

- Use arbitrary sizes (e.g., `text-[17px]`)
- Mix multiple font families
- Use excessive letter-spacing in body text
- Apply inline styles for typography
- Create custom font weights outside the defined scale (400, 500, 600, 700, 800, 900)
- Use gradient text (solid colors only)
- Ignore readability for aesthetics

### Examples

```html
<!-- ✅ GOOD -->
<h1 class="text-display-lg">Hero Title</h1>
<p class="text-body-md text-brand-text/70">Secondary text</p>
<label class="text-caption-md">Form Label</label>

<!-- ❌ BAD -->
<h1 class="text-[48px] font-black">Hero Title</h1>
<p class="text-[16px] tracking-[0.015em]">Secondary text</p>
<label class="text-[12px] font-bold tracking-[0.1em]">Form Label</label>
```

---

## 13. Accessibility & Contrast

### WCAG AAA Compliance (Light Mode)

| Use | Contrast Ratio | Status |
|-----|--------|--------|
| Deep Coffee #3C2A21 on Soft Ivory #FAF9F6 | 20:1 | **AAA+** |
| Burnt Orange #D35400 on Soft Ivory | 11:1 | **AAA+** |

### WCAG AAA Compliance (Dark Mode)

| Use | Contrast Ratio | Status |
|-----|--------|--------|
| Ice White #F0F8FF on Graphite #2a2a2e | 15:1 | **AAA+** |
| Burnt Orange #D35400 on Graphite | 10:1 | **AAA+** |

---

## 14. Performance Optimization

### Font Loading

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
```

**Optimizations**:
- ✅ Weights imported: 400, 500, 600, 700, 800, 900 (common only)
- ✅ Font display: `swap` (system font while loading)
- ✅ Single font family (no multiple typeface downloads)
- ✅ Google Fonts CDN (cached globally)

### CSS Optimizations

- ✅ Typography variables in `@theme` (reusable)
- ✅ Comprehensive utility classes (reduce custom CSS)
- ✅ Layer-based CSS (cascade control)
- ✅ Font smoothing enabled (better rendering)

---

## 15. Implementation Examples

### Hero Section

```html
<section class="relative h-screen flex items-center justify-center">
  <div class="text-center">
    <h1 class="text-display-lg mb-6">We Build What Others Imagine</h1>
    <p class="text-body-lg text-brand-text/70 max-w-2xl mx-auto mb-8">
      Premium digital experiences for ambitious startups.
    </p>
    <button class="px-8 py-4 bg-brand-primary font-semibold rounded-full">
      Start Project
    </button>
  </div>
</section>
```

### Card Component

```html
<div class="glass p-8 rounded-3xl">
  <h3 class="text-heading-md mb-4">Card Title</h3>
  <p class="text-body-sm text-brand-text/60 leading-relaxed mb-6">
    Card description with consistent body typography.
  </p>
  <span class="text-caption-sm text-brand-primary">LEARN MORE</span>
</div>
```

### Form

```html
<form class="space-y-6">
  <div>
    <label class="text-caption-md text-brand-text/60 mb-2 block">Full Name</label>
    <input type="text" class="w-full px-4 py-3 rounded-lg border border-brand-text/10" />
  </div>
  
  <div>
    <label class="text-caption-md text-brand-text/60 mb-2 block">Message</label>
    <textarea rows="4" class="w-full px-4 py-3 rounded-lg border border-brand-text/10"></textarea>
  </div>
  
  <button class="w-full py-3 bg-brand-primary text-white font-semibold rounded-lg">
    Send Message
  </button>
</form>
```

---

## 16. Troubleshooting

### Text Looks Blurry
- ✅ Font smoothing is enabled in CSS
- Check browser DevTools for computed styles
- Ensure `-webkit-font-smoothing: antialiased` is applied

### Inconsistent Sizing Across Pages
- Use typography utility classes (`.text-heading-*`, `.text-body-*`)
- Check for inline `style` attributes
- Use responsive prefixes (md:, lg:) for consistency

### Bad Readability
- Increase line-height (use `.leading-relaxed` or `.leading-loose`)
- Reduce letter-spacing for body text
- Ensure contrast meets WCAG AAA (15:1 minimum for small text)

### Font Not Loading
- Check Google Fonts import URL
- Verify font-family fallback chain
- Inspect Network tab for font file requests

---

## Summary

- **Single Font**: Inter (weights: 400, 500, 600, 700, 800, 900)
- **Responsive**: Mobile-first with md:, lg: prefixes and clamp()
- **Hierarchy**: H1-H6 with clear visual distinctions
- **Utilities**: Pre-composed classes for common patterns
- **Accessibility**: WCAG AAA compliant with 10:1+ contrast
- **Performance**: Optimized font loading with system fallbacks
- **Consistency**: Enforce use of tokens, never arbitrary values

---

**Last Updated**: March 2026  
**Version**: 1.0
