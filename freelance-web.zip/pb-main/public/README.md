# Public assets
Place your logo.png here.
